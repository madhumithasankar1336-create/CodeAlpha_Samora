import { Router, Request, Response } from 'express';
import { Category } from '../models/Category.ts';
import { protect, adminOnly, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Get all categories
router.get('/', async (_req: Request, res: Response) => {
  try {
    const categories = await Category.find().sort({ displayOrder: 1, name: 1 });
    res.json({ success: true, categories });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching categories' });
  }
});

// Admin: Create category
router.post('/', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const { name, description, image, displayOrder } = req.body;
    if (!name) {
      res.status(400).json({ success: false, message: 'Category name is required' });
      return;
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    const category = await Category.create({
      name,
      slug,
      description: description || '',
      image: image || '',
      displayOrder: displayOrder || 0
    });

    res.status(201).json({ success: true, category });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed to create category' });
  }
});

// Admin: Update category
router.put('/:id', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const { name, description, image, isActive, displayOrder } = req.body;
    const category = await Category.findById(req.params.id);
    if (!category) {
      res.status(404).json({ success: false, message: 'Category not found' });
      return;
    }

    if (name) {
      category.name = name;
      category.slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
    }
    if (description !== undefined) category.description = description;
    if (image !== undefined) category.image = image;
    if (isActive !== undefined) category.isActive = isActive;
    if (displayOrder !== undefined) category.displayOrder = displayOrder;

    await category.save();
    res.json({ success: true, category });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed to update category' });
  }
});

// Admin: Delete category
router.delete('/:id', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const category = await Category.findByIdAndDelete(req.params.id);
    if (!category) {
      res.status(404).json({ success: false, message: 'Category not found' });
      return;
    }
    res.json({ success: true, message: 'Category deleted successfully' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed to delete category' });
  }
});

export default router;
