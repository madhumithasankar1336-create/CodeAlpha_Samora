import { Router, Request, Response } from 'express';
import { Coupon } from '../models/Coupon.ts';
import { protect, adminOnly, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Validate coupon for checkout
router.post('/validate', async (req: Request, res: Response) => {
  try {
    const { code, cartTotal } = req.body;
    if (!code) {
      res.status(400).json({ success: false, message: 'Coupon code is required' });
      return;
    }

    const coupon = await Coupon.findOne({ code: code.toUpperCase().trim() });
    if (!coupon) {
      res.status(404).json({ success: false, message: 'Invalid coupon code' });
      return;
    }

    if (!coupon.isActive) {
      res.status(400).json({ success: false, message: 'This coupon is no longer active' });
      return;
    }

    if (new Date() > coupon.validUntil) {
      res.status(400).json({ success: false, message: 'This coupon has expired' });
      return;
    }

    if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
      res.status(400).json({ success: false, message: 'This coupon usage limit has been reached' });
      return;
    }

    const subtotal = Number(cartTotal) || 0;
    if (subtotal < coupon.minPurchaseAmount) {
      res.status(400).json({
        success: false,
        message: `Minimum order amount of $${coupon.minPurchaseAmount} required for this coupon`
      });
      return;
    }

    let discount = 0;
    if (coupon.discountType === 'percentage') {
      discount = (subtotal * coupon.discountAmount) / 100;
      if (coupon.maxDiscountAmount && discount > coupon.maxDiscountAmount) {
        discount = coupon.maxDiscountAmount;
      }
    } else {
      discount = coupon.discountAmount;
    }

    // Ensure discount doesn't exceed subtotal
    discount = Math.min(discount, subtotal);
    discount = Math.round(discount * 100) / 100;

    res.json({
      success: true,
      code: coupon.code,
      discountAmount: discount,
      discountType: coupon.discountType,
      discountValue: coupon.discountAmount,
      message: `Coupon ${coupon.code} applied! Saved $${discount.toFixed(2)}`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error validating coupon' });
  }
});

// GET all coupons (Admin)
router.get('/', protect, adminOnly, async (_req: AuthRequest, res: Response) => {
  try {
    const coupons = await Coupon.find().sort({ createdAt: -1 });
    res.json({ success: true, coupons });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching coupons' });
  }
});

// POST new coupon (Admin)
router.post('/', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const {
      code,
      description,
      discountType,
      discountAmount,
      minPurchaseAmount,
      maxDiscountAmount,
      validUntil,
      usageLimit
    } = req.body;

    if (!code || !discountType || discountAmount === undefined || !validUntil) {
      res.status(400).json({ success: false, message: 'Please provide code, type, amount, and expiry date' });
      return;
    }

    const coupon = await Coupon.create({
      code: code.toUpperCase().trim(),
      description: description || '',
      discountType,
      discountAmount: Number(discountAmount),
      minPurchaseAmount: Number(minPurchaseAmount) || 0,
      maxDiscountAmount: maxDiscountAmount ? Number(maxDiscountAmount) : undefined,
      validUntil: new Date(validUntil),
      usageLimit: usageLimit ? Number(usageLimit) : 500,
      isActive: true
    });

    res.status(201).json({ success: true, coupon });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed creating coupon' });
  }
});

// DELETE coupon (Admin)
router.delete('/:id', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const coupon = await Coupon.findByIdAndDelete(req.params.id);
    if (!coupon) {
      res.status(404).json({ success: false, message: 'Coupon not found' });
      return;
    }
    res.json({ success: true, message: 'Coupon deleted successfully' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed deleting coupon' });
  }
});

export default router;
