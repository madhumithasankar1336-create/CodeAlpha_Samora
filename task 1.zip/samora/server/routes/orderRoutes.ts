import { Router, Response } from 'express';
import { Order } from '../models/Order.ts';
import { Product } from '../models/Product.ts';
import { Coupon } from '../models/Coupon.ts';
import { protect, optionalAuth, adminOnly, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Create new order
router.post('/', optionalAuth, async (req: AuthRequest, res: Response) => {
  try {
    const {
      orderItems,
      shippingAddress,
      paymentMethod = 'cod',
      customerDetails,
      couponCode
    } = req.body;

    if (!orderItems || !orderItems.length) {
      res.status(400).json({ success: false, message: 'Your cart is empty' });
      return;
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.addressLine || !shippingAddress.city) {
      res.status(400).json({ success: false, message: 'Complete shipping address is required' });
      return;
    }

    const customer = {
      name: customerDetails?.name || req.user?.name || shippingAddress.fullName,
      email: customerDetails?.email || req.user?.email || 'customer@samora.com',
      phone: customerDetails?.phone || req.user?.phone || shippingAddress.phone || ''
    };

    // Calculate item prices and verify stock
    let itemsPrice = 0;
    const verifiedItems = [];

    for (const item of orderItems) {
      const product = await Product.findById(item.productId || item.product);
      if (!product) {
        res.status(404).json({ success: false, message: `Product ${item.name || ''} not found` });
        return;
      }

      if (product.stock < item.quantity) {
        res.status(400).json({
          success: false,
          message: `Insufficient stock for "${product.name}". Available: ${product.stock}`
        });
        return;
      }

      const activePrice = product.discountPrice && product.discountPrice > 0 ? product.discountPrice : product.price;
      itemsPrice += activePrice * item.quantity;

      verifiedItems.push({
        product: product._id,
        name: product.name,
        image: product.images[0] || '',
        price: activePrice,
        quantity: item.quantity
      });

      // Decrement stock
      product.stock -= item.quantity;
      await product.save();
    }

    // Shipping rules: Free shipping over $150, else $15
    const shippingPrice = itemsPrice >= 150 ? 0 : 15;

    // Apply Coupon if valid
    let discountAmount = 0;
    let couponApplied = undefined;

    if (couponCode) {
      const coupon = await Coupon.findOne({ code: couponCode.toUpperCase().trim(), isActive: true });
      if (coupon && new Date() <= coupon.validUntil && itemsPrice >= coupon.minPurchaseAmount) {
        if (coupon.discountType === 'percentage') {
          discountAmount = (itemsPrice * coupon.discountAmount) / 100;
          if (coupon.maxDiscountAmount && discountAmount > coupon.maxDiscountAmount) {
            discountAmount = coupon.maxDiscountAmount;
          }
        } else {
          discountAmount = coupon.discountAmount;
        }
        discountAmount = Math.min(discountAmount, itemsPrice);
        discountAmount = Math.round(discountAmount * 100) / 100;

        couponApplied = {
          code: coupon.code,
          discountAmount
        };

        coupon.usedCount += 1;
        await coupon.save();
      }
    }

    const totalPrice = Math.max(0, itemsPrice + shippingPrice - discountAmount);
    const orderNumber = `SAM-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;

    const order = await Order.create({
      orderNumber,
      user: req.user?._id,
      customerDetails: customer,
      orderItems: verifiedItems,
      shippingAddress,
      paymentMethod,
      paymentStatus: paymentMethod === 'cod' ? 'pending' : 'completed',
      itemsPrice: Math.round(itemsPrice * 100) / 100,
      shippingPrice,
      discountAmount,
      totalPrice: Math.round(totalPrice * 100) / 100,
      couponApplied,
      orderStatus: 'placed',
      statusTimeline: [
        {
          status: 'placed',
          timestamp: new Date(),
          note: `Order received and confirmed. Payment mode: ${paymentMethod.toUpperCase()}`
        }
      ]
    });

    res.status(201).json({
      success: true,
      message: 'Order placed successfully!',
      order
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error creating order' });
  }
});

// GET user orders
router.get('/my-orders', protect, async (req: AuthRequest, res: Response) => {
  try {
    const orders = await Order.find({ user: req.user!._id }).sort({ createdAt: -1 });
    res.json({ success: true, orders });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching user orders' });
  }
});

// Track order by orderNumber
router.get('/track/:orderNumber', async (req, res: Response) => {
  try {
    const order = await Order.findOne({ orderNumber: req.params.orderNumber });
    if (!order) {
      res.status(404).json({ success: false, message: 'Order number not found' });
      return;
    }

    res.json({
      success: true,
      order: {
        orderNumber: order.orderNumber,
        createdAt: order.createdAt,
        orderStatus: order.orderStatus,
        statusTimeline: order.statusTimeline,
        totalPrice: order.totalPrice,
        itemsCount: order.orderItems.reduce((acc, i) => acc + i.quantity, 0),
        shippingCity: order.shippingAddress.city,
        shippingCountry: order.shippingAddress.country
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error tracking order' });
  }
});

// GET single order by ID
router.get('/:id', optionalAuth, async (req: AuthRequest, res: Response) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      res.status(404).json({ success: false, message: 'Order not found' });
      return;
    }

    // Check permission if user is attached
    if (order.user && req.user && req.user.role !== 'admin' && order.user.toString() !== req.user._id.toString()) {
      res.status(403).json({ success: false, message: 'Not authorized to view this order' });
      return;
    }

    res.json({ success: true, order });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching order' });
  }
});

// Admin: Get all orders
router.get('/admin/all', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query: any = {};
    if (status && status !== 'all') {
      query.orderStatus = status;
    }

    const pageNum = Math.max(1, Number(page));
    const pageSize = Math.max(1, Number(limit));

    const total = await Order.countDocuments(query);
    const orders = await Order.find(query)
      .sort({ createdAt: -1 })
      .skip((pageNum - 1) * pageSize)
      .limit(pageSize);

    res.json({
      success: true,
      orders,
      page: pageNum,
      pages: Math.ceil(total / pageSize) || 1,
      total
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching admin orders' });
  }
});

// Admin: Update order status
router.put('/admin/:id/status', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const { status, note } = req.body;
    const order = await Order.findById(req.params.id);
    if (!order) {
      res.status(404).json({ success: false, message: 'Order not found' });
      return;
    }

    order.orderStatus = status;
    order.statusTimeline.push({
      status,
      timestamp: new Date(),
      note: note || `Status updated to ${status} by administrator`
    });

    if (status === 'delivered') {
      order.paymentStatus = 'completed';
    }

    await order.save();
    res.json({ success: true, order });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed updating order status' });
  }
});

export default router;
