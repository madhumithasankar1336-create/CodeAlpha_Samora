import { Router, Response } from 'express';
import { User } from '../models/User.ts';
import { Product } from '../models/Product.ts';
import { protect, AuthRequest } from '../middleware/auth.ts';
import { Types } from 'mongoose';

const router = Router();

// GET user's wishlist
router.get('/', protect, async (req: AuthRequest, res: Response) => {
  try {
    const user = await User.findById(req.user!._id).populate({
      path: 'wishlist',
      populate: { path: 'category', select: 'name slug' }
    });

    res.json({
      success: true,
      wishlist: user?.wishlist || []
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching wishlist' });
  }
});

// Toggle product in wishlist
router.post('/toggle/:productId', protect, async (req: AuthRequest, res: Response) => {
  try {
    const { productId } = req.params;
    const user = await User.findById(req.user!._id);
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    const prodObjectId = new Types.ObjectId(productId);
    const index = user.wishlist.findIndex(id => id.toString() === productId);

    let isAdded = false;
    if (index > -1) {
      // Remove
      user.wishlist.splice(index, 1);
    } else {
      // Add
      const exists = await Product.findById(productId);
      if (!exists) {
        res.status(404).json({ success: false, message: 'Product not found' });
        return;
      }
      user.wishlist.push(prodObjectId);
      isAdded = true;
    }

    await user.save();

    res.json({
      success: true,
      isWishlisted: isAdded,
      message: isAdded ? 'Added to your wishlist' : 'Removed from your wishlist',
      wishlist: user.wishlist
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error updating wishlist' });
  }
});

export default router;
