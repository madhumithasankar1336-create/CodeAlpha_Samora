import { Router, Request, Response } from 'express';
import { Product } from '../models/Product.ts';
import { Category } from '../models/Category.ts';
import { Review } from '../models/Review.ts';
import { protect, adminOnly, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// GET /api/products
// Supports: keyword, category (id or slug), minPrice, maxPrice, minRating, sort, page, limit
router.get('/', async (req: Request, res: Response) => {
  try {
    const {
      keyword,
      category,
      minPrice,
      maxPrice,
      minRating,
      sort,
      page = 1,
      limit = 12
    } = req.query;

    const query: any = {};

    // Keyword search
    if (keyword && typeof keyword === 'string' && keyword.trim() !== '') {
      const searchRegex = new RegExp(keyword.trim(), 'i');
      query.$or = [
        { name: searchRegex },
        { description: searchRegex },
        { shortDescription: searchRegex },
        { tags: searchRegex }
      ];
    }

    // Category filter
    if (category && typeof category === 'string' && category !== 'all') {
      // Check if it's an ObjectId or a slug
      if (category.match(/^[0-9a-fA-F]{24}$/)) {
        query.category = category;
      } else {
        const catDoc = await Category.findOne({ slug: category });
        if (catDoc) {
          query.category = catDoc._id;
        }
      }
    }

    // Price range filter
    if (minPrice !== undefined || maxPrice !== undefined) {
      query.price = {};
      if (minPrice !== undefined && !isNaN(Number(minPrice))) {
        query.price.$gte = Number(minPrice);
      }
      if (maxPrice !== undefined && !isNaN(Number(maxPrice))) {
        query.price.$lte = Number(maxPrice);
      }
    }

    // Rating filter
    if (minRating !== undefined && !isNaN(Number(minRating))) {
      query.rating = { $gte: Number(minRating) };
    }

    // Sorting
    let sortOptions: any = { createdAt: -1 }; // default newest
    if (sort === 'price-low') {
      sortOptions = { price: 1 };
    } else if (sort === 'price-high') {
      sortOptions = { price: -1 };
    } else if (sort === 'rating') {
      sortOptions = { rating: -1 };
    } else if (sort === 'popular') {
      sortOptions = { numReviews: -1, rating: -1 };
    }

    const pageNum = Math.max(1, Number(page));
    const pageSize = Math.max(1, Number(limit));
    const skip = (pageNum - 1) * pageSize;

    const total = await Product.countDocuments(query);
    const products = await Product.find(query)
      .populate('category', 'name slug')
      .sort(sortOptions)
      .skip(skip)
      .limit(pageSize);

    res.json({
      success: true,
      products,
      page: pageNum,
      pages: Math.ceil(total / pageSize) || 1,
      total
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching products' });
  }
});

// GET /api/products/featured
router.get('/featured', async (_req: Request, res: Response) => {
  try {
    const products = await Product.find({ isFeatured: true })
      .populate('category', 'name slug')
      .limit(8);
    res.json({ success: true, products });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching featured products' });
  }
});

// GET /api/products/:id
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const product = await Product.findById(req.params.id).populate('category', 'name slug');
    if (!product) {
      res.status(404).json({ success: false, message: 'Product not found' });
      return;
    }

    const reviews = await Review.find({ product: product._id }).sort({ createdAt: -1 });

    res.json({
      success: true,
      product,
      reviews
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching product' });
  }
});

// POST /api/products (Admin only)
router.post('/', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const {
      name,
      description,
      shortDescription,
      price,
      discountPrice,
      category,
      images,
      stock,
      isFeatured,
      tags,
      specifications
    } = req.body;

    if (!name || !price || !category) {
      res.status(400).json({ success: false, message: 'Name, price, and category are required' });
      return;
    }

    const slug = `${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '')}-${Date.now().toString().slice(-4)}`;

    const product = await Product.create({
      name,
      slug,
      description: description || name,
      shortDescription: shortDescription || '',
      price: Number(price),
      discountPrice: discountPrice ? Number(discountPrice) : 0,
      category,
      images: Array.isArray(images) && images.length ? images : ['/src/assets/images/product_silk_dress_1793026300287.jpg'],
      stock: stock !== undefined ? Number(stock) : 10,
      isFeatured: Boolean(isFeatured),
      tags: Array.isArray(tags) ? tags : [],
      specifications: Array.isArray(specifications) ? specifications : []
    });

    const populated = await Product.findById(product._id).populate('category', 'name slug');
    res.status(201).json({ success: true, product: populated });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed to create product' });
  }
});

// PUT /api/products/:id (Admin only)
router.put('/:id', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      res.status(404).json({ success: false, message: 'Product not found' });
      return;
    }

    const updates = req.body;
    if (updates.name) {
      product.name = updates.name;
    }
    if (updates.description !== undefined) product.description = updates.description;
    if (updates.shortDescription !== undefined) product.shortDescription = updates.shortDescription;
    if (updates.price !== undefined) product.price = Number(updates.price);
    if (updates.discountPrice !== undefined) product.discountPrice = Number(updates.discountPrice);
    if (updates.category) product.category = updates.category;
    if (updates.images) product.images = updates.images;
    if (updates.stock !== undefined) product.stock = Number(updates.stock);
    if (updates.isFeatured !== undefined) product.isFeatured = Boolean(updates.isFeatured);
    if (updates.tags) product.tags = updates.tags;
    if (updates.specifications) product.specifications = updates.specifications;

    await product.save();
    const populated = await Product.findById(product._id).populate('category', 'name slug');
    res.json({ success: true, product: populated });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed to update product' });
  }
});

// DELETE /api/products/:id (Admin only)
router.delete('/:id', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) {
      res.status(404).json({ success: false, message: 'Product not found' });
      return;
    }
    await Review.deleteMany({ product: product._id });
    res.json({ success: true, message: 'Product and associated reviews deleted' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed to delete product' });
  }
});

export default router;
