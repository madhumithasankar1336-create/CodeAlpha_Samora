import { Router, Response } from 'express';
import { Order } from '../models/Order.ts';
import { Product } from '../models/Product.ts';
import { User } from '../models/User.ts';
import { Category } from '../models/Category.ts';
import { protect, adminOnly, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// GET admin dashboard stats
router.get('/stats', protect, adminOnly, async (_req: AuthRequest, res: Response) => {
  try {
    const [
      totalProducts,
      totalOrders,
      totalUsers,
      totalCategories,
      deliveredOrders,
      recentOrders
    ] = await Promise.all([
      Product.countDocuments(),
      Order.countDocuments(),
      User.countDocuments(),
      Category.countDocuments(),
      Order.find({ orderStatus: { $ne: 'cancelled' } }),
      Order.find().sort({ createdAt: -1 }).limit(6)
    ]);

    const totalRevenue = deliveredOrders.reduce((sum, order) => sum + (order.totalPrice || 0), 0);

    // Orders by status
    const statusCounts: Record<string, number> = {
      placed: 0,
      processing: 0,
      shipped: 0,
      delivered: 0,
      cancelled: 0
    };

    deliveredOrders.forEach(o => {
      if (statusCounts[o.orderStatus] !== undefined) {
        statusCounts[o.orderStatus]++;
      }
    });

    res.json({
      success: true,
      stats: {
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        totalOrders,
        totalProducts,
        totalUsers,
        totalCategories,
        statusCounts,
        recentOrders
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching admin metrics' });
  }
});

// GET all users
router.get('/users', protect, adminOnly, async (_req: AuthRequest, res: Response) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json({ success: true, users });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching users' });
  }
});

// Update user role
router.put('/users/:id/role', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const { role } = req.body;
    if (!['admin', 'customer'].includes(role)) {
      res.status(400).json({ success: false, message: 'Invalid role specified' });
      return;
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    user.role = role;
    await user.save();

    res.json({
      success: true,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed updating user role' });
  }
});

export default router;
