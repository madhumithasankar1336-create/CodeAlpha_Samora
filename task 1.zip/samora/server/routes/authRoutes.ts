import { Router, Response } from 'express';
import { User } from '../models/User.ts';
import { generateToken, protect, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// Register
router.post('/register', async (req, res: Response) => {
  try {
    const { name, email, password, phone } = req.body;

    if (!name || !email || !password) {
      res.status(400).json({ success: false, message: 'Please provide name, email, and password' });
      return;
    }

    const normalizedEmail = email.toLowerCase().trim();
    const existing = await User.findOne({ email: normalizedEmail });
    if (existing) {
      res.status(400).json({ success: false, message: 'An account with this email already exists' });
      return;
    }

    // First user or specific admin email can be admin
    const isFirstUser = (await User.countDocuments()) === 0;
    const role = isFirstUser || normalizedEmail === 'admin@samora.com' ? 'admin' : 'customer';

    const user = await User.create({
      name,
      email: normalizedEmail,
      password,
      phone: phone || '',
      role
    });

    const token = generateToken(user._id.toString(), user.role);

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 30 * 24 * 60 * 60 * 1000
    });

    res.status(201).json({
      success: true,
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        addresses: user.addresses,
        wishlist: user.wishlist
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Registration failed' });
  }
});

// Login
router.post('/login', async (req, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ success: false, message: 'Please provide email and password' });
      return;
    }

    const normalizedEmail = email.toLowerCase().trim();
    const user = await User.findOne({ email: normalizedEmail });

    if (!user) {
      res.status(401).json({ success: false, message: 'Invalid email or password' });
      return;
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      res.status(401).json({ success: false, message: 'Invalid email or password' });
      return;
    }

    const token = generateToken(user._id.toString(), user.role);

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 30 * 24 * 60 * 60 * 1000
    });

    res.json({
      success: true,
      token,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        addresses: user.addresses,
        wishlist: user.wishlist
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Login failed' });
  }
});

// Logout
router.post('/logout', (_req, res: Response) => {
  res.clearCookie('token');
  res.json({ success: true, message: 'Logged out successfully' });
});

// Get current user profile
router.get('/me', protect, async (req: AuthRequest, res: Response) => {
  try {
    const user = await User.findById(req.user!._id).select('-password').populate('wishlist');
    res.json({ success: true, user });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed fetching profile' });
  }
});

// Update profile
router.put('/profile', protect, async (req: AuthRequest, res: Response) => {
  try {
    const { name, phone } = req.body;
    const user = await User.findById(req.user!._id);
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    if (name) user.name = name;
    if (phone !== undefined) user.phone = phone;

    await user.save();

    res.json({
      success: true,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        addresses: user.addresses,
        wishlist: user.wishlist
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Profile update failed' });
  }
});

// Add Address
router.post('/address', protect, async (req: AuthRequest, res: Response) => {
  try {
    const { fullName, phone, addressLine, city, postalCode, country, isDefault } = req.body;
    const user = await User.findById(req.user!._id);
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    if (isDefault) {
      user.addresses.forEach(a => (a.isDefault = false));
    }

    user.addresses.push({
      fullName,
      phone,
      addressLine,
      city,
      postalCode,
      country: country || 'India',
      isDefault: Boolean(isDefault) || user.addresses.length === 0
    });

    await user.save();
    res.json({ success: true, addresses: user.addresses });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed adding address' });
  }
});

// Delete Address
router.delete('/address/:addressId', protect, async (req: AuthRequest, res: Response) => {
  try {
    const user = await User.findById(req.user!._id);
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    user.addresses = user.addresses.filter(a => a._id?.toString() !== req.params.addressId);
    await user.save();
    res.json({ success: true, addresses: user.addresses });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed deleting address' });
  }
});

export default router;
