import { Router, Request, Response } from 'express';
import { Review } from '../models/Review.ts';
import { Product } from '../models/Product.ts';
import { protect, adminOnly, AuthRequest } from '../middleware/auth.ts';

const router = Router();

// GET reviews for product
router.get('/product/:productId', async (req: Request, res: Response) => {
  try {
    const reviews = await Review.find({ product: req.params.productId }).sort({ createdAt: -1 });
    res.json({ success: true, reviews });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Error fetching reviews' });
  }
});

// POST review (Customer only)
router.post('/product/:productId', protect, async (req: AuthRequest, res: Response) => {
  try {
    const { rating, comment, title } = req.body;
    const productId = req.params.productId;

    if (!rating || !comment) {
      res.status(400).json({ success: false, message: 'Rating and review comment are required' });
      return;
    }

    const product = await Product.findById(productId);
    if (!product) {
      res.status(404).json({ success: false, message: 'Product not found' });
      return;
    }

    // Check if user already reviewed
    const existing = await Review.findOne({ product: productId, user: req.user!._id });
    if (existing) {
      existing.rating = Number(rating);
      existing.comment = comment;
      if (title) existing.title = title;
      await existing.save();
    } else {
      await Review.create({
        product: productId,
        user: req.user!._id,
        userName: req.user!.name,
        rating: Number(rating),
        title: title || '',
        comment,
        isVerifiedPurchase: true
      });
    }

    // Recalculate product rating & numReviews
    const allReviews = await Review.find({ product: productId });
    const avgRating = allReviews.reduce((sum, r) => sum + r.rating, 0) / (allReviews.length || 1);

    product.rating = Math.round(avgRating * 10) / 10;
    product.numReviews = allReviews.length;
    await product.save();

    res.status(201).json({
      success: true,
      message: 'Review saved successfully',
      rating: product.rating,
      numReviews: product.numReviews
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed saving review' });
  }
});

// DELETE review (Admin only)
router.delete('/:id', protect, adminOnly, async (req: AuthRequest, res: Response) => {
  try {
    const review = await Review.findByIdAndDelete(req.params.id);
    if (!review) {
      res.status(404).json({ success: false, message: 'Review not found' });
      return;
    }

    const allReviews = await Review.find({ product: review.product });
    const avgRating = allReviews.length > 0 ? allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length : 5;
    await Product.findByIdAndUpdate(review.product, {
      rating: Math.round(avgRating * 10) / 10,
      numReviews: allReviews.length
    });

    res.json({ success: true, message: 'Review deleted successfully' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message || 'Failed deleting review' });
  }
});

export default router;
