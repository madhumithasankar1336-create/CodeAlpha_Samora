import { connectDB } from './config/db.ts';
import { User } from './models/User.ts';
import { Category } from './models/Category.ts';
import { Product } from './models/Product.ts';
import { Coupon } from './models/Coupon.ts';
import { Order } from './models/Order.ts';
import { Review } from './models/Review.ts';

export async function seedDatabase(force: boolean = false): Promise<void> {
  try {
    const existingProducts = await Product.countDocuments();
    if (existingProducts >= 12 && !force) {
      console.log('Database already contains all products. Skipping seed.');
      return;
    }

    console.log('Starting SAMORA E-commerce database seed with expanded catalog...');

    if (force || existingProducts < 12) {
      await User.deleteMany({});
      await Category.deleteMany({});
      await Product.deleteMany({});
      await Coupon.deleteMany({});
      await Order.deleteMany({});
      await Review.deleteMany({});
    }

    // 1. Seed Users
    const adminUser = await User.create({
      name: 'Eleanor Vance (Admin)',
      email: 'admin@samora.com',
      password: 'Admin@123',
      role: 'admin',
      phone: '+1 (555) 392-1084',
      addresses: [
        {
          fullName: 'Eleanor Vance',
          phone: '+1 (555) 392-1084',
          addressLine: '450 Fifth Avenue, Suite 1800',
          city: 'New York',
          postalCode: '10018',
          country: 'United States',
          isDefault: true
        }
      ]
    });

    const customerUser = await User.create({
      name: 'Madhumitha S.',
      email: 'customer@samora.com',
      password: 'Customer@123',
      role: 'customer',
      phone: '+91 98401 23456',
      addresses: [
        {
          fullName: 'Madhumitha Sankar',
          phone: '+91 98401 23456',
          addressLine: '42 Lotus Promenade, Palm Grove',
          city: 'Chennai',
          postalCode: '600004',
          country: 'India',
          isDefault: true
        }
      ]
    });

    // 2. Seed Categories
    const categories = await Category.insertMany([
      {
        name: 'Silk & Dresses',
        slug: 'silk-dresses',
        description: 'Bespoke Mulberry silk slips, pleated gowns, and evening silhouettes.',
        image: '/src/assets/images/product_silk_dress_1793026300287.jpg',
        displayOrder: 1
      },
      {
        name: 'Skincare & Elixirs',
        slug: 'skincare-elixirs',
        description: 'Botanical rose cell actives, cold-pressed seed oils, and quartz serums.',
        image: '/src/assets/images/product_beauty_serum_1793026300989.jpg',
        displayOrder: 2
      },
      {
        name: 'Handbags & Leather',
        slug: 'handbags-leather',
        description: 'Italian full-grain calfskin and artisanal chevron quilted statement bags.',
        image: '/src/assets/images/product_leather_bag_1793026300615.jpg',
        displayOrder: 3
      },
      {
        name: 'Fragrance & Scents',
        slug: 'fragrance-scents',
        description: 'High-concentration crystal flacon extraits with Grasse rose and vanilla.',
        image: '/src/assets/images/product_luxury_perfume_1793026302154.jpg',
        displayOrder: 4
      },
      {
        name: 'Jewelry & Fine Gems',
        slug: 'jewelry-gems',
        description: 'Handcrafted 18k rose gold vermeil and natural rose quartz pendants.',
        image: '/src/assets/images/product_quartz_ring_1793027271539.jpg',
        displayOrder: 5
      }
    ]);

    const catMap = new Map(categories.map(c => [c.slug, c._id]));

    // 3. Seed Products (12 Unique Luxury Creations)
    const products = await Product.insertMany([
      {
        name: 'The Rose Pleated Mulberry Silk Gown',
        slug: 'the-rose-pleated-mulberry-silk-gown',
        category: catMap.get('silk-dresses'),
        price: 340,
        discountPrice: 289,
        description: 'Handcrafted from 100% 22-momme pure mulberry silk, this pleated evening gown features an architectural sweetheart bustier, delicate shoulder straps, and a cascade of sunburst micro-pleats that drift gracefully with every step.',
        shortDescription: 'Pure 22-momme mulberry silk with hand-pleated sunburst detailing.',
        stock: 14,
        rating: 4.9,
        numReviews: 28,
        isFeatured: true,
        images: ['/src/assets/images/product_silk_dress_1793026300287.jpg'],
        tags: ['silk', 'evening', 'gown', 'pink', 'luxury'],
        specifications: [
          { key: 'Material', value: '100% Pure Mulberry Silk (22-Momme)' },
          { key: 'Lining', value: '100% Habotai Silk Breathable Slip' },
          { key: 'Fit', value: 'Floor length with fitted empire bodice' },
          { key: 'Care', value: 'Dry Clean or Hand Wash Cold with Silk Detergent' }
        ]
      },
      {
        name: 'Aurora Botanical Radiance Serum & Quartz Roller',
        slug: 'aurora-botanical-radiance-serum-quartz-roller',
        category: catMap.get('skincare-elixirs'),
        price: 115,
        discountPrice: 95,
        description: 'Formulated with cold-pressed Damascus Rose essential extracts, botanical hyaluronic acid, and micro-algae squalane, paired with a solid Madagascar rose quartz facial lymphatic drainage roller.',
        shortDescription: '36ml bio-active rose botanical nectar with rose quartz lymphatic roller.',
        stock: 45,
        rating: 5.0,
        numReviews: 42,
        isFeatured: true,
        images: ['/src/assets/images/product_beauty_serum_1793026300989.jpg'],
        tags: ['skincare', 'serum', 'roller', 'botanical', 'glow'],
        specifications: [
          { key: 'Volume', value: '36ml / 1.2 fl. oz.' },
          { key: 'Key Actives', value: 'Damascus Rosehip Oil, Bakuchiol, Niacinamide 5%' },
          { key: 'Roller Material', value: 'Grade-A Natural Madagascar Rose Quartz' },
          { key: 'Skin Type', value: 'Suitable for all skin types, dermatologically tested' }
        ]
      },
      {
        name: 'Akrélia Chevron Quilted Calfskin Shoulder Bag',
        slug: 'akrelia-chevron-quilted-calfskin-shoulder-bag',
        category: catMap.get('handbags-leather'),
        price: 490,
        discountPrice: 420,
        description: 'Constructed from velvety soft Italian pebble calfskin in custom dusty blush pink. Features precision chevron quilting, champagne gold turn-lock closure, and dual leather-woven chain straps.',
        shortDescription: 'Supple Italian calfskin with champagne gold turn-lock hardware.',
        stock: 8,
        rating: 4.8,
        numReviews: 19,
        isFeatured: true,
        images: ['/src/assets/images/product_leather_bag_1793026300615.jpg'],
        tags: ['handbag', 'leather', 'quilted', 'gold-chain', 'accessories'],
        specifications: [
          { key: 'Dimensions', value: '28cm W x 19cm H x 9cm D' },
          { key: 'Hardware', value: '18K Pale Champagne Gold Anti-Tarnish Finish' },
          { key: 'Interior', value: 'Suede lining with dual zipped compartments' },
          { key: 'Origin', value: 'Artisan Workshop, Florence, Italy' }
        ]
      },
      {
        name: 'Lumière Pétale Extrait de Parfum (100ml)',
        slug: 'lumiere-petale-extrait-de-parfum',
        category: catMap.get('fragrance-scents'),
        price: 210,
        discountPrice: 185,
        description: 'An ethereal composition opening with frosted lychee and pink peppercorn, blooming into heart notes of May peony, centifolia rose, and magnolia, anchored on crystalline white amber and Tahitian vanilla.',
        shortDescription: 'Sensual floral extrait with May peony, centifolia rose, and white amber.',
        stock: 25,
        rating: 4.9,
        numReviews: 35,
        isFeatured: true,
        images: ['/src/assets/images/product_luxury_perfume_1793026302154.jpg'],
        tags: ['perfume', 'fragrance', 'rose', 'extrait', 'crystal'],
        specifications: [
          { key: 'Concentration', value: 'Extrait de Parfum (28% Oil Concentration)' },
          { key: 'Top Notes', value: 'Frosted Lychee, Pink Peppercorn, Mandarin Zest' },
          { key: 'Heart Notes', value: 'Centifolia Rose, May Peony, White Magnolia' },
          { key: 'Base Notes', value: 'Solar Amber, Cashmere Musk, Tahitian Vanilla' }
        ]
      },
      {
        name: 'Rosée 18K Gold & Cushion Rose Quartz Ring',
        slug: 'rosee-18k-gold-cushion-rose-quartz-ring',
        category: catMap.get('jewelry-gems'),
        price: 180,
        discountPrice: 155,
        description: 'Hand-set cushion-cut unheated rose quartz weighing 4.5 carats in an open gallery setting of recycled 18K solid vermeil over 925 sterling silver.',
        shortDescription: '4.5 ct cushion-cut rose quartz in 18k rose gold vermeil.',
        stock: 12,
        rating: 4.9,
        numReviews: 16,
        isFeatured: true,
        images: ['/src/assets/images/product_quartz_ring_1793027271539.jpg'],
        tags: ['jewelry', 'ring', 'gemstone', 'gold', 'quartz'],
        specifications: [
          { key: 'Gemstone', value: 'Natural Madagascar Rose Quartz (4.5 Carats)' },
          { key: 'Metal', value: '18K Rose Gold Vermeil (3.5 Microns) over 925 Silver' },
          { key: 'Band Width', value: '1.8mm comfort fit' }
        ]
      },
      {
        name: 'Pastel Rose Cashmere & Silk Wrap Scarf',
        slug: 'pastel-rose-cashmere-silk-wrap-scarf',
        category: catMap.get('silk-dresses'),
        price: 160,
        discountPrice: 135,
        description: 'Woven in the Scottish Highlands blending 70% Mongolian cashmere and 30% Mulberry silk for supreme featherweight softness and gentle drape.',
        shortDescription: '70% grade-A cashmere, 30% silk with hand-rolled delicate fringes.',
        stock: 30,
        rating: 4.7,
        numReviews: 14,
        isFeatured: false,
        images: ['/src/assets/images/product_cashmere_scarf_1793027272551.jpg'],
        tags: ['cashmere', 'silk', 'scarf', 'winter-spring', 'luxury'],
        specifications: [
          { key: 'Dimensions', value: '200cm x 75cm' },
          { key: 'Composition', value: '70% Mongolian Cashmere, 30% Silk' }
        ]
      },
      {
        name: 'Rosewater & Hyaluronic Cloud Hydrating Mist',
        slug: 'rosewater-hyaluronic-cloud-hydrating-mist',
        category: catMap.get('skincare-elixirs'),
        price: 58,
        discountPrice: 48,
        description: 'Ultra-fine micro-mist saturated with pure steam-distilled organic rose petal hydrosol, triple-molecular hyaluronic acid, and white tea extract.',
        shortDescription: 'Organic steam-distilled rose petal hydrosol with triple HA.',
        stock: 50,
        rating: 4.8,
        numReviews: 22,
        isFeatured: false,
        images: ['/src/assets/images/product_hydrating_mist_1793027272519.jpg'],
        tags: ['mist', 'hydrating', 'skincare', 'rosewater'],
        specifications: [
          { key: 'Volume', value: '120ml / 4 fl. oz.' },
          { key: 'Certification', value: '100% Organic, Vegan & Cruelty Free' }
        ]
      },
      {
        name: 'Monogrammed Blush Petite Leather Cardholder',
        slug: 'monogrammed-blush-petite-leather-cardholder',
        category: catMap.get('handbags-leather'),
        price: 95,
        discountPrice: 80,
        description: 'Compact 5-slot slim wallet crafted from scratch-resistant Saffiano calf leather with champagne gold SAMORA insignia stamping.',
        shortDescription: 'Saffiano calfskin with 5 card slots and RFID protection.',
        stock: 22,
        rating: 4.9,
        numReviews: 18,
        isFeatured: false,
        images: ['/src/assets/images/product_leather_cardholder_1793027272598.jpg'],
        tags: ['cardholder', 'wallet', 'leather', 'saffiano'],
        specifications: [
          { key: 'Dimensions', value: '10.5cm x 7.5cm' },
          { key: 'Capacity', value: '5 Card Slots + Central Cash Slip' }
        ]
      },
      {
        name: 'Élodie French Chantilly Lace & Silk Slip Dress',
        slug: 'elodie-french-chantilly-lace-silk-slip-dress',
        category: catMap.get('silk-dresses'),
        price: 275,
        discountPrice: 235,
        description: 'Cut on the bias from liquid blush silk charmeuse, accented with hand-appliquéd antique French Chantilly floral lace at the scalloped neckline and vented hemline.',
        shortDescription: 'Liquid silk charmeuse with hand-appliquéd French Chantilly lace.',
        stock: 18,
        rating: 4.9,
        numReviews: 31,
        isFeatured: true,
        images: ['/src/assets/images/product_lace_slip_dress_1793028219071.jpg'],
        tags: ['silk', 'slip', 'lace', 'lingerie', 'dress', 'pink'],
        specifications: [
          { key: 'Fabric', value: '100% 19-Momme Grade 6A Silk Charmeuse' },
          { key: 'Lace Trim', value: 'Calais-Caudry French Chantilly Lace' },
          { key: 'Straps', value: 'Adjustable 18k gold-plated sliders' }
        ]
      },
      {
        name: 'Velours de Rose Peptide Overnight Repair Crème',
        slug: 'velours-de-rose-peptide-overnight-repair-creme',
        category: catMap.get('skincare-elixirs'),
        price: 135,
        discountPrice: 115,
        description: 'An intensive nightly restorative emulsion enriched with Alpine Rose stem cells, copper tri-peptides, and cold-pressed camellia seed oil housed in a frosted blush glass jar.',
        shortDescription: 'Alpine rose stem cells with bio-active copper tri-peptides.',
        stock: 35,
        rating: 5.0,
        numReviews: 27,
        isFeatured: true,
        images: ['/src/assets/images/product_rose_face_cream_1793028220017.jpg'],
        tags: ['creme', 'moisturizer', 'peptides', 'overnight', 'skincare'],
        specifications: [
          { key: 'Net Weight', value: '50ml / 1.7 oz.' },
          { key: 'Key Actives', value: 'Alpine Rose Stem Cells, Matrixyl 3000, Squalane' },
          { key: 'Application', value: 'Apply onto cleansed face and décolletage before sleep' }
        ]
      },
      {
        name: 'Sienna Structured Mini Top-Handle Leather Satchel',
        slug: 'sienna-structured-mini-top-handle-leather-satchel',
        category: catMap.get('handbags-leather'),
        price: 460,
        discountPrice: 395,
        description: 'A timeless architectural silhouette crafted from scratch-resistant grained Tuscan calf leather in soft mauve rose with a secure champagne gold flip-clasp.',
        shortDescription: 'Structured Tuscan grained calf leather with gold flip-clasp.',
        stock: 11,
        rating: 4.8,
        numReviews: 15,
        isFeatured: true,
        images: ['/src/assets/images/product_mini_top_handle_bag_1793028220585.jpg'],
        tags: ['handbag', 'satchel', 'top-handle', 'calfskin', 'accessories'],
        specifications: [
          { key: 'Dimensions', value: '22cm W x 17cm H x 8.5cm D' },
          { key: 'Strap', value: 'Detachable & adjustable leather crossbody strap' },
          { key: 'Hardware', value: '18K Pale Gold Plated Solid Brass' }
        ]
      },
      {
        name: 'Céleste Baroque Pearl & Rose Quartz Pendant Necklace',
        slug: 'celeste-baroque-pearl-rose-quartz-pendant-necklace',
        category: catMap.get('jewelry-gems'),
        price: 220,
        discountPrice: 190,
        description: 'A glowing natural freshwater baroque pearl crowned over a faceted teardrop Madagascar rose quartz drop, suspended on an 18K solid vermeil fine link chain.',
        shortDescription: 'Luminous baroque pearl and faceted rose quartz in 18k vermeil.',
        stock: 15,
        rating: 4.9,
        numReviews: 24,
        isFeatured: true,
        images: ['/src/assets/images/product_pearl_necklace_1793028220521.jpg'],
        tags: ['necklace', 'jewelry', 'pearl', 'gemstone', 'rose-quartz', 'gold'],
        specifications: [
          { key: 'Pearl Type', value: 'Grade-AAA Cultured Freshwater Baroque Pearl' },
          { key: 'Drop Stone', value: 'Natural Faceted Teardrop Rose Quartz' },
          { key: 'Chain Length', value: '45cm + 5cm extender in 18K Rose Gold Vermeil' }
        ]
      }
    ]);

    // 4. Seed Reviews
    await Review.insertMany([
      {
        product: products[0]._id,
        user: customerUser._id,
        userName: 'Madhumitha S.',
        rating: 5,
        title: 'Breathtaking craftsmanship and drape',
        comment: 'The silk fabric is substantial yet floats effortlessly. Wore this to an evening gala and received countless compliments. The blush tone is warm, muted, and utterly regal.',
        isVerifiedPurchase: true
      },
      {
        product: products[1]._id,
        user: customerUser._id,
        userName: 'Madhumitha S.',
        rating: 5,
        title: 'Obsessed with the morning glow',
        comment: 'The serum absorbs without any tacky residue. Pairing it with the chilled quartz roller has visibly de-puffed my cheekbones and leaves an angelic radiant glow.',
        isVerifiedPurchase: true
      },
      {
        product: products[2]._id,
        user: adminUser._id,
        userName: 'Eleanor Vance',
        rating: 5,
        title: 'Every stitch is perfection',
        comment: 'The leather aroma and tactile finish rival Parisian heritage fashion houses. The gold hardware has the exact warm champagne luster as described.',
        isVerifiedPurchase: true
      },
      {
        product: products[8]._id,
        user: customerUser._id,
        userName: 'Madhumitha S.',
        rating: 5,
        title: 'Exquisite French Lace detailing',
        comment: 'The Chantilly lace feels so delicate and soft against the skin, yet the silk charmeuse has marvelous weight and drape. Unmatched luxury.',
        isVerifiedPurchase: true
      },
      {
        product: products[9]._id,
        user: adminUser._id,
        userName: 'Eleanor Vance',
        rating: 5,
        title: 'Velvety hydration overnight',
        comment: 'Woke up with remarkably plump and luminous skin. The rose aroma is natural and soothing without being overpowering.',
        isVerifiedPurchase: true
      }
    ]);

    // 5. Seed Coupons
    await Coupon.insertMany([
      {
        code: 'SAMORA15',
        description: '15% Off storewide for new & existing patrons',
        discountType: 'percentage',
        discountAmount: 15,
        minPurchaseAmount: 50,
        maxDiscountAmount: 100,
        validUntil: new Date('2027-12-31'),
        isActive: true,
        usageLimit: 1000
      },
      {
        code: 'PINK20',
        description: '20% Off orders exceeding $100',
        discountType: 'percentage',
        discountAmount: 20,
        minPurchaseAmount: 100,
        maxDiscountAmount: 150,
        validUntil: new Date('2027-12-31'),
        isActive: true,
        usageLimit: 500
      },
      {
        code: 'LUXURY50',
        description: 'Flat $50 Off on orders above $250',
        discountType: 'fixed',
        discountAmount: 50,
        minPurchaseAmount: 250,
        validUntil: new Date('2027-12-31'),
        isActive: true,
        usageLimit: 250
      }
    ]);

    // 6. Seed Sample Orders
    await Order.create({
      orderNumber: 'SAM-894102-301',
      user: customerUser._id,
      customerDetails: {
        name: customerUser.name,
        email: customerUser.email,
        phone: customerUser.phone || '+91 98401 23456'
      },
      orderItems: [
        {
          product: products[0]._id,
          name: products[0].name,
          image: products[0].images[0],
          price: 289,
          quantity: 1
        },
        {
          product: products[1]._id,
          name: products[1].name,
          image: products[1].images[0],
          price: 95,
          quantity: 1
        }
      ],
      shippingAddress: {
        fullName: 'Madhumitha Sankar',
        phone: '+91 98401 23456',
        addressLine: '42 Lotus Promenade, Palm Grove',
        city: 'Chennai',
        postalCode: '600004',
        country: 'India'
      },
      paymentMethod: 'cod',
      paymentStatus: 'pending',
      itemsPrice: 384,
      shippingPrice: 0,
      discountAmount: 50,
      totalPrice: 334,
      couponApplied: {
        code: 'LUXURY50',
        discountAmount: 50
      },
      orderStatus: 'shipped',
      statusTimeline: [
        {
          status: 'placed',
          timestamp: new Date(Date.now() - 48 * 3600 * 1000),
          note: 'Order confirmed and registered in SAMORA boutique registry.'
        },
        {
          status: 'processing',
          timestamp: new Date(Date.now() - 36 * 3600 * 1000),
          note: 'Artisanal gift-wrapped packaging completed.'
        },
        {
          status: 'shipped',
          timestamp: new Date(Date.now() - 12 * 3600 * 1000),
          note: 'Dispatched via Express Courier. Tracking ID: EXP-SAM-894102.'
        }
      ]
    });

    console.log('SAMORA E-commerce expanded database seed completed successfully!');
  } catch (error) {
    console.error('Error during database seed:', error);
  }
}

// If run directly via CLI (tsx server/seed.ts)
if (process.argv[1]?.includes('seed.ts')) {
  (async () => {
    await connectDB();
    await seedDatabase(true);
    process.exit(0);
  })();
}
