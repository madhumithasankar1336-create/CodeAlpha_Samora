import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

let mongoMemoryInstance: MongoMemoryServer | null = null;

export async function connectDB(): Promise<void> {
  const uri = process.env.MONGODB_URI;

  if (uri && uri.trim() !== '') {
    try {
      console.log('Connecting to provided MongoDB URI...');
      await mongoose.connect(uri);
      console.log('Connected to MongoDB via URI successfully.');
      return;
    } catch (err) {
      console.warn('Failed connecting to MONGODB_URI. Falling back to embedded MongoMemoryServer...', err);
    }
  }

  try {
    console.log('Initializing embedded MongoDB Memory Server for seamless local execution...');
    mongoMemoryInstance = await MongoMemoryServer.create();
    const memoryUri = mongoMemoryInstance.getUri();
    await mongoose.connect(memoryUri);
    console.log(`Connected to embedded MongoDB at ${memoryUri}`);
  } catch (memoryErr) {
    console.error('Critical: Failed to initialize MongoDB connection:', memoryErr);
    throw memoryErr;
  }
}

export async function disconnectDB(): Promise<void> {
  await mongoose.disconnect();
  if (mongoMemoryInstance) {
    await mongoMemoryInstance.stop();
  }
}
