import mongoose, { Document, Schema, Types } from 'mongoose';

export interface IOrderItem {
  product: Types.ObjectId;
  name: string;
  image: string;
  price: number;
  quantity: number;
}

export interface IStatusTimeline {
  status: 'placed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  timestamp: Date;
  note: string;
}

export interface IOrder extends Document {
  _id: Types.ObjectId;
  orderNumber: string;
  user?: Types.ObjectId;
  customerDetails: {
    name: string;
    email: string;
    phone: string;
  };
  orderItems: IOrderItem[];
  shippingAddress: {
    fullName: string;
    phone: string;
    addressLine: string;
    city: string;
    postalCode: string;
    country: string;
  };
  paymentMethod: 'cod' | 'card' | 'upi';
  paymentStatus: 'pending' | 'completed' | 'failed';
  itemsPrice: number;
  shippingPrice: number;
  discountAmount: number;
  totalPrice: number;
  couponApplied?: {
    code: string;
    discountAmount: number;
  };
  orderStatus: 'placed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  statusTimeline: IStatusTimeline[];
  createdAt: Date;
  updatedAt: Date;
}

const OrderItemSchema = new Schema<IOrderItem>(
  {
    product: { type: Schema.Types.ObjectId, ref: 'Product', required: true },
    name: { type: String, required: true },
    image: { type: String, required: true },
    price: { type: Number, required: true },
    quantity: { type: Number, required: true, min: 1 }
  },
  { _id: false }
);

const StatusTimelineSchema = new Schema<IStatusTimeline>(
  {
    status: {
      type: String,
      enum: ['placed', 'processing', 'shipped', 'delivered', 'cancelled'],
      required: true
    },
    timestamp: { type: Date, default: Date.now },
    note: { type: String, default: '' }
  },
  { _id: false }
);

const OrderSchema = new Schema<IOrder>(
  {
    orderNumber: { type: String, required: true, unique: true },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    customerDetails: {
      name: { type: String, required: true },
      email: { type: String, required: true },
      phone: { type: String, required: true }
    },
    orderItems: [OrderItemSchema],
    shippingAddress: {
      fullName: { type: String, required: true },
      phone: { type: String, required: true },
      addressLine: { type: String, required: true },
      city: { type: String, required: true },
      postalCode: { type: String, required: true },
      country: { type: String, required: true }
    },
    paymentMethod: { type: String, enum: ['cod', 'card', 'upi'], default: 'cod' },
    paymentStatus: { type: String, enum: ['pending', 'completed', 'failed'], default: 'pending' },
    itemsPrice: { type: Number, required: true },
    shippingPrice: { type: Number, required: true, default: 0 },
    discountAmount: { type: Number, default: 0 },
    totalPrice: { type: Number, required: true },
    couponApplied: {
      code: { type: String },
      discountAmount: { type: Number }
    },
    orderStatus: {
      type: String,
      enum: ['placed', 'processing', 'shipped', 'delivered', 'cancelled'],
      default: 'placed'
    },
    statusTimeline: [StatusTimelineSchema]
  },
  { timestamps: true }
);

export const Order = mongoose.model<IOrder>('Order', OrderSchema);
