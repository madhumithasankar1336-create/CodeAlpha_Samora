import os
import zipfile

def create_project_zip():
    output_filename = "public/samora-ecommerce.zip"
    os.makedirs("public", exist_ok=True)
    
    exclude_dirs = {"node_modules", ".git", "dist", ".cache", "tmp", "__pycache__"}
    exclude_files = {"public/samora-ecommerce.zip", "create_zip.py", "bun.lock"}
    
    print(f"Creating zip archive {output_filename}...")
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk("."):
            # Exclude directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            for file in files:
                filepath = os.path.normpath(os.path.join(root, file))
                if filepath in exclude_files or filepath.startswith("./public/samora-ecommerce.zip"):
                    continue
                if any(ex in filepath.split(os.sep) for ex in exclude_dirs):
                    continue
                # Relative path inside archive
                arcname = os.path.relpath(filepath, ".")
                zipf.write(filepath, arcname)
                print(f"  Added: {arcname}")

    file_size_mb = os.path.getsize(output_filename) / (1024 * 1024)
    print(f"Project ZIP created successfully: {output_filename} ({file_size_mb:.2f} MB)")

if __name__ == "__main__":
    create_project_zip()
