/**
 * SAMORA E-Commerce Engine
 * Complete Vanilla JavaScript Frontend Client
 */

class SamoraApp {
  constructor() {
    this.apiBase = '/api';
    this.token = localStorage.getItem('samora_token') || null;
    this.currentUser = null;
    this.cart = JSON.parse(localStorage.getItem('samora_cart') || '[]');
    this.appliedCoupon = JSON.parse(localStorage.getItem('samora_coupon') || 'null');
    this.wishlist = [];
    this.categories = [];
    this.products = [];
    this.currentProduct = null;
    this.filters = {
      category: 'all',
      keyword: '',
      minPrice: undefined,
      maxPrice: undefined,
      minRating: undefined,
      sort: 'newest',
      page: 1,
      limit: 8
    };
    this.pagination = { total: 0, page: 1, pages: 1 };
    this.searchDebounceTimer = null;
    this.authMode = 'login';
    this.activeAdminTab = 'overview';
    this.activeAccountTab = 'orders';

    // Global accessibility for inline HTML handlers
    window.app = this;
  }

  async init() {
    console.log('🌸 Initializing SAMORA boutique client...');
    this.updateCartBadge();
    await this.checkAuthStatus();
    await this.loadCategories();
    await this.loadProducts();
    if (this.currentUser) {
      await this.loadWishlist();
    }
    this.bindKeyboardShortcuts();
  }

  // --- HTTP API HELPER ---
  async apiRequest(endpoint, method = 'GET', body = null, silent = false) {
    const headers = { 'Content-Type': 'application/json' };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    try {
      const response = await fetch(`${this.apiBase}${endpoint}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : null
      });

      const data = await response.json().catch(() => ({}));

      // If token expired or user deleted/no longer exists, automatically clear stale credentials
      if (response.status === 401) {
        this.token = null;
        this.currentUser = null;
        localStorage.removeItem('samora_token');
        if (silent || endpoint === '/auth/me') {
          return { success: false, message: 'Unauthenticated' };
        }
      }

      if (!response.ok) {
        throw new Error(data.message || `API error (${response.status})`);
      }
      return data;
    } catch (err) {
      if (!silent && endpoint !== '/auth/me') {
        console.error(`Request failed [${method} ${endpoint}]:`, err);
      }
      throw err;
    }
  }

  // --- TOAST NOTIFICATIONS ---
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `p-3.5 rounded-xl shadow-lg border text-xs font-medium flex items-center gap-3 transition-all transform duration-300 pointer-events-auto animate-fade-in ${
      type === 'success'
        ? 'bg-rose-900 text-white border-rose-700'
        : type === 'error'
        ? 'bg-red-900 text-white border-red-700'
        : 'bg-slate-900 text-white border-slate-700'
    }`;

    const icon = type === 'success'
      ? `<svg class="w-4 h-4 text-rose-300 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>`
      : type === 'error'
      ? `<svg class="w-4 h-4 text-red-300 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M6 18L18 6M6 6l12 12"/></svg>`
      : `<svg class="w-4 h-4 text-rose-300 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`;

    toast.innerHTML = `${icon}<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  // --- KEYBOARD & NAVIGATION ---
  bindKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.closeAllModals();
      }
    });
  }

  closeAllModals() {
    this.toggleCartDrawer(false);
    this.closeProductModal();
    this.closeCheckoutModal();
    this.closeTrackModal();
    this.closeWishlistModal();
    this.closeAccountModal();
    this.closeAuthModal();
    this.closeAdminModal();
  }

  scrollToSection(sectionId, event) {
    if (event) event.preventDefault();
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }

  navigateHome(event) {
    if (event) event.preventDefault();
    this.resetFilters();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // --- AUTHENTICATION ---
  async checkAuthStatus() {
    if (!this.token) {
      this.renderUserNav();
      return;
    }

    try {
      const data = await this.apiRequest('/auth/me', 'GET', null, true);
      if (data && data.success && data.user) {
        this.currentUser = data.user;
        this.wishlist = (data.user.wishlist || []).map((p) => (typeof p === 'object' ? p._id : p));
        this.renderUserNav();
        this.updateWishlistBadge();
      } else {
        this.logout(false);
      }
    } catch {
      this.logout(false);
    }
  }

  renderUserNav() {
    const container = document.getElementById('user-nav-container');
    if (!container) return;

    if (this.currentUser) {
      const isAdmin = this.currentUser.role === 'admin';
      container.innerHTML = `
        <div class="flex items-center gap-2">
          ${isAdmin ? `
            <button onclick="app.openAdminModal()" class="px-2.5 py-1.5 text-xs font-mono font-bold text-white bg-slate-900 hover:bg-rose-950 rounded-lg transition-colors cursor-pointer flex items-center gap-1">
              <span class="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
              Admin
            </button>
          ` : ''}
          <button onclick="app.openAccountModal()" class="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-rose-600 bg-rose-50/70 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors cursor-pointer">
            <span class="w-5 h-5 rounded-full bg-rose-200 text-rose-800 flex items-center justify-center text-[10px] font-bold">
              ${this.currentUser.name ? this.currentUser.name[0].toUpperCase() : 'U'}
            </span>
            <span class="hidden sm:inline">${this.currentUser.name.split(' ')[0]}</span>
          </button>
        </div>
      `;
    } else {
      container.innerHTML = `
        <button onclick="app.openAuthModal()" class="px-4 py-2 text-xs font-semibold uppercase tracking-wider text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer">
          Sign In
        </button>
      `;
    }
  }

  openAuthModal(mode = 'login') {
    this.setAuthMode(mode);
    const modal = document.getElementById('auth-modal');
    if (modal) modal.classList.remove('hidden');
  }

  closeAuthModal() {
    const modal = document.getElementById('auth-modal');
    if (modal) modal.classList.add('hidden');
  }

  setAuthMode(mode) {
    this.authMode = mode;
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const tabLogin = document.getElementById('auth-tab-login');
    const tabRegister = document.getElementById('auth-tab-register');

    if (mode === 'login') {
      loginForm?.classList.remove('hidden');
      registerForm?.classList.add('hidden');
      tabLogin?.classList.add('text-rose-600', 'border-b-2', 'border-rose-600');
      tabLogin?.classList.remove('text-slate-400');
      tabRegister?.classList.remove('text-rose-600', 'border-b-2', 'border-rose-600');
      tabRegister?.classList.add('text-slate-400');
    } else {
      loginForm?.classList.add('hidden');
      registerForm?.classList.remove('hidden');
      tabRegister?.classList.add('text-rose-600', 'border-b-2', 'border-rose-600');
      tabRegister?.classList.remove('text-slate-400');
      tabLogin?.classList.remove('text-rose-600', 'border-b-2', 'border-rose-600');
      tabLogin?.classList.add('text-slate-400');
    }
  }

  fillDemoAccount(role) {
    if (role === 'admin') {
      const emailInput = document.getElementById('login-email');
      const passInput = document.getElementById('login-password');
      if (emailInput) emailInput.value = 'admin@samora.com';
      if (passInput) passInput.value = 'Admin@123';
      this.setAuthMode('login');
      this.showToast('Filled Demo Administrator credentials', 'info');
    } else {
      const emailInput = document.getElementById('login-email');
      const passInput = document.getElementById('login-password');
      if (emailInput) emailInput.value = 'customer@samora.com';
      if (passInput) passInput.value = 'Customer@123';
      this.setAuthMode('login');
      this.showToast('Filled Demo Customer credentials', 'info');
    }
  }

  async handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
      const data = await this.apiRequest('/auth/login', 'POST', { email, password });
      this.token = data.token;
      localStorage.setItem('samora_token', data.token);
      this.currentUser = data.user;
      this.closeAuthModal();
      this.renderUserNav();
      await this.loadWishlist();
      this.showToast(`Welcome back, ${data.user.name}!`, 'success');
    } catch (err) {
      this.showToast(err.message || 'Login failed', 'error');
    }
  }

  async handleRegister(event) {
    event.preventDefault();
    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const phone = document.getElementById('reg-phone').value;
    const password = document.getElementById('reg-password').value;

    try {
      const data = await this.apiRequest('/auth/register', 'POST', { name, email, phone, password });
      this.token = data.token;
      localStorage.setItem('samora_token', data.token);
      this.currentUser = data.user;
      this.closeAuthModal();
      this.renderUserNav();
      this.showToast(`Account created! Welcome to SAMORA, ${data.user.name}.`, 'success');
    } catch (err) {
      this.showToast(err.message || 'Registration failed', 'error');
    }
  }

  logout(showNotification = true) {
    this.token = null;
    this.currentUser = null;
    localStorage.removeItem('samora_token');
    this.renderUserNav();
    this.closeAccountModal();
    this.closeAdminModal();
    if (showNotification) {
      this.showToast('You have been logged out safely', 'info');
    }
  }

  // --- CATEGORIES ---
  async loadCategories() {
    try {
      const data = await this.apiRequest('/categories');
      this.categories = data.categories || [];
      this.renderCategoryCards();
      this.renderCategoryFilterTabs();
    } catch (err) {
      console.error('Failed loading categories:', err);
    }
  }

  renderCategoryCards() {
    const container = document.getElementById('category-cards-container');
    if (!container) return;

    if (!this.categories.length) {
      container.innerHTML = `<p class="col-span-full text-center text-xs text-slate-400">No categories found.</p>`;
      return;
    }

    container.innerHTML = this.categories
      .map(
        (cat) => `
        <div onclick="app.filterByCategory('${cat.slug}')" class="group cursor-pointer bg-rose-50/50 hover:bg-rose-100/60 p-4 rounded-xl border border-rose-100 text-center transition-all hover:-translate-y-1 hover:shadow-sm">
          <div class="w-14 h-14 mx-auto rounded-full bg-white p-1 border border-rose-200 mb-3 overflow-hidden shadow-xs">
            <img src="${cat.image || '/src/assets/images/product_beauty_serum_1793026300989.jpg'}" alt="${cat.name}" class="w-full h-full object-cover rounded-full group-hover:scale-110 transition-transform duration-300" />
          </div>
          <h3 class="text-xs font-semibold text-slate-900 group-hover:text-rose-600 transition-colors">${cat.name}</h3>
          <p class="text-[10px] text-slate-400 mt-1 line-clamp-1">${cat.description || 'Explore collection'}</p>
        </div>
      `
      )
      .join('');
  }

  renderCategoryFilterTabs() {
    const container = document.getElementById('category-filter-tabs');
    if (!container) return;

    const allActive = this.filters.category === 'all';
    let html = `
      <button onclick="app.filterByCategory('all')" class="px-3.5 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
        allActive ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-rose-50'
      }">
        All Items
      </button>
    `;

    html += this.categories
      .map((cat) => {
        const isActive = this.filters.category === cat.slug;
        return `
          <button onclick="app.filterByCategory('${cat.slug}')" class="px-3.5 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
            isActive ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900 hover:bg-rose-50'
          }">
            ${cat.name}
          </button>
        `;
      })
      .join('');

    container.innerHTML = html;
  }

  filterByCategory(slug) {
    this.filters.category = slug;
    this.filters.page = 1;
    this.renderCategoryFilterTabs();
    this.loadProducts();
    this.scrollToSection('shop');
  }

  // --- PRODUCTS CATALOG ---
  async loadProducts() {
    const grid = document.getElementById('product-grid');
    if (grid) {
      grid.innerHTML = Array(4)
        .fill(0)
        .map(
          () => `
          <div class="bg-white rounded-2xl border border-rose-100 p-4 animate-pulse space-y-3">
            <div class="aspect-4/3 bg-rose-50 rounded-xl"></div>
            <div class="h-4 bg-rose-50 rounded w-3/4"></div>
            <div class="h-3 bg-rose-50 rounded w-1/2"></div>
            <div class="h-8 bg-rose-50 rounded"></div>
          </div>
        `
        )
        .join('');
    }

    try {
      const params = new URLSearchParams({
        page: this.filters.page.toString(),
        limit: this.filters.limit.toString(),
        sort: this.filters.sort
      });

      if (this.filters.category && this.filters.category !== 'all') {
        params.append('category', this.filters.category);
      }
      if (this.filters.keyword) {
        params.append('keyword', this.filters.keyword);
      }
      if (this.filters.minPrice !== undefined) {
        params.append('minPrice', this.filters.minPrice.toString());
      }
      if (this.filters.maxPrice !== undefined) {
        params.append('maxPrice', this.filters.maxPrice.toString());
      }
      if (this.filters.minRating !== undefined) {
        params.append('minRating', this.filters.minRating.toString());
      }

      const data = await this.apiRequest(`/products?${params.toString()}`);
      this.products = data.products || [];
      this.pagination = { total: data.total || 0, page: data.page || 1, pages: data.pages || 1 };

      this.renderProductGrid();
      this.renderPagination();

      const countLabel = document.getElementById('catalog-count-label');
      if (countLabel) {
        countLabel.textContent = `${this.pagination.total} artisanal items found`;
      }
    } catch (err) {
      if (grid) {
        grid.innerHTML = `
          <div class="col-span-full py-12 text-center text-rose-700 bg-rose-50/50 rounded-2xl border border-rose-200">
            <p class="font-medium text-sm">Failed to load products</p>
            <button onclick="app.loadProducts()" class="mt-2 text-xs underline font-semibold">Try Again</button>
          </div>
        `;
      }
    }
  }

  renderProductGrid() {
    const grid = document.getElementById('product-grid');
    if (!grid) return;

    if (!this.products.length) {
      grid.innerHTML = `
        <div class="col-span-full py-16 text-center text-slate-500 bg-white rounded-2xl border border-rose-100">
          <svg class="w-10 h-10 text-rose-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
          <p class="font-serif text-lg font-bold text-slate-800">No matching creations found</p>
          <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">Try refining your keyword search or adjusting the price/rating filters.</p>
          <button onclick="app.resetFilters()" class="mt-4 px-4 py-2 bg-rose-50 text-rose-700 font-semibold text-xs rounded-lg hover:bg-rose-100 border border-rose-200 cursor-pointer">
            Reset All Filters
          </button>
        </div>
      `;
      return;
    }

    grid.innerHTML = this.products
      .map((p) => {
        const isWish = this.wishlist.includes(p._id);
        const hasDiscount = p.discountPrice && p.discountPrice > 0 && p.discountPrice < p.price;
        const currentPrice = hasDiscount ? p.discountPrice : p.price;
        const imgSrc = p.images && p.images[0] ? p.images[0] : '/src/assets/images/product_silk_dress_1793026300287.jpg';

        return `
          <div class="luxury-card group bg-white rounded-2xl border border-rose-100/80 p-3.5 flex flex-col justify-between overflow-hidden shadow-xs">
            <div>
              <!-- Image Container -->
              <div class="relative rounded-xl overflow-hidden aspect-4/3 bg-rose-50/50 mb-3.5 cursor-pointer" onclick="app.openProductModal('${p._id}')">
                <img src="${imgSrc}" alt="${p.name}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerpolicy="no-referrer" />
                
                <!-- Wishlist Toggle Button -->
                <button onclick="event.stopPropagation(); app.toggleWishlist('${p._id}')" class="absolute top-2.5 right-2.5 w-8 h-8 rounded-full bg-white/90 backdrop-blur-xs flex items-center justify-center text-slate-400 hover:text-rose-600 shadow-xs transition-colors cursor-pointer" title="Save to Wishlist">
                  <svg class="w-4 h-4 ${isWish ? 'fill-rose-600 text-rose-600' : ''}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                </button>

                ${hasDiscount ? `
                  <div class="absolute top-2.5 left-2.5 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded tracking-wide uppercase shadow-xs">
                    Sale
                  </div>
                ` : ''}

                <!-- Quick View Overlay trigger on hover -->
                <div class="absolute inset-x-2 bottom-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onclick="event.stopPropagation(); app.openProductModal('${p._id}')" class="w-full py-2 bg-white/95 text-slate-800 text-xs font-semibold rounded-lg shadow-sm hover:bg-rose-50 transition-colors">
                    Quick View
                  </button>
                </div>
              </div>

              <!-- Product Info -->
              <div class="space-y-1">
                <div class="flex items-center justify-between text-xs text-slate-400">
                  <span class="uppercase tracking-wider text-[10px] font-semibold text-rose-600">${p.category?.name || 'SAMORA'}</span>
                  <div class="flex items-center gap-1 text-amber-500 font-semibold text-[11px]">
                    <svg class="w-3 h-3 fill-amber-400" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    <span>${p.rating.toFixed(1)}</span>
                    <span class="text-slate-400 font-normal">(${p.numReviews})</span>
                  </div>
                </div>

                <h3 onclick="app.openProductModal('${p._id}')" class="text-sm font-semibold text-slate-900 group-hover:text-rose-600 transition-colors line-clamp-1 cursor-pointer">
                  ${p.name}
                </h3>
                <p class="text-xs text-slate-500 line-clamp-1">${p.shortDescription || p.description}</p>
              </div>
            </div>

            <!-- Price & Add To Bag -->
            <div class="mt-4 pt-3 border-t border-rose-100 flex items-center justify-between gap-2">
              <div class="tabular-nums">
                <span class="text-base font-bold text-slate-900 font-serif">$${currentPrice.toFixed(2)}</span>
                ${hasDiscount ? `<span class="text-xs text-slate-400 line-through ml-1.5">$${p.price.toFixed(2)}</span>` : ''}
              </div>
              <button onclick="app.addToCart('${p._id}')" class="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-200 hover:border-rose-600 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                <span>Add</span>
              </button>
            </div>
          </div>
        `;
      })
      .join('');
  }

  renderPagination() {
    const container = document.getElementById('pagination-controls');
    if (!container) return;

    if (this.pagination.pages <= 1) {
      container.innerHTML = '';
      return;
    }

    let buttons = `
      <button onclick="app.goToPage(${this.pagination.page - 1})" ${this.pagination.page === 1 ? 'disabled class="opacity-40 cursor-not-allowed"' : 'class="cursor-pointer"'} class="px-3 py-1.5 text-xs font-medium rounded-lg border border-rose-200 bg-white text-slate-700 hover:bg-rose-50">
        Previous
      </button>
    `;

    for (let i = 1; i <= this.pagination.pages; i++) {
      const isCurrent = i === this.pagination.page;
      buttons += `
        <button onclick="app.goToPage(${i})" class="w-8 h-8 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
          isCurrent ? 'bg-rose-600 text-white' : 'bg-white border border-rose-200 text-slate-700 hover:bg-rose-50'
        }">
          ${i}
        </button>
      `;
    }

    buttons += `
      <button onclick="app.goToPage(${this.pagination.page + 1})" ${this.pagination.page === this.pagination.pages ? 'disabled class="opacity-40 cursor-not-allowed"' : 'class="cursor-pointer"'} class="px-3 py-1.5 text-xs font-medium rounded-lg border border-rose-200 bg-white text-slate-700 hover:bg-rose-50">
        Next
      </button>
    `;

    container.innerHTML = buttons;
  }

  goToPage(pageNum) {
    if (pageNum < 1 || pageNum > this.pagination.pages) return;
    this.filters.page = pageNum;
    this.loadProducts();
    this.scrollToSection('shop');
  }

  // --- SEARCH & FILTER CONTROLS ---
  toggleSearchBox() {
    const box = document.getElementById('quick-search-bar');
    if (box) {
      box.classList.toggle('hidden');
      if (!box.classList.contains('hidden')) {
        document.getElementById('header-search-input')?.focus();
      }
    }
  }

  handleSearchInput(event) {
    const val = event.target.value;
    clearTimeout(this.searchDebounceTimer);
    this.searchDebounceTimer = setTimeout(() => {
      this.filters.keyword = val.trim();
      this.filters.page = 1;
      this.loadProducts();
      // Sync inputs if different
      const headerInput = document.getElementById('header-search-input');
      const catalogInput = document.getElementById('catalog-search-input');
      if (headerInput && headerInput !== event.target) headerInput.value = val;
      if (catalogInput && catalogInput !== event.target) catalogInput.value = val;
    }, 300);
  }

  clearSearch() {
    this.filters.keyword = '';
    this.filters.page = 1;
    const headerInput = document.getElementById('header-search-input');
    const catalogInput = document.getElementById('catalog-search-input');
    if (headerInput) headerInput.value = '';
    if (catalogInput) catalogInput.value = '';
    this.loadProducts();
  }

  handleFilterChange() {
    const priceVal = document.getElementById('price-filter-select')?.value;
    const ratingVal = document.getElementById('rating-filter-select')?.value;
    const sortVal = document.getElementById('sort-select')?.value;

    if (priceVal === 'all') {
      this.filters.minPrice = undefined;
      this.filters.maxPrice = undefined;
    } else if (priceVal === '0-100') {
      this.filters.minPrice = 0;
      this.filters.maxPrice = 100;
    } else if (priceVal === '100-250') {
      this.filters.minPrice = 100;
      this.filters.maxPrice = 250;
    } else if (priceVal === '250-500') {
      this.filters.minPrice = 250;
      this.filters.maxPrice = 500;
    } else if (priceVal === '500+') {
      this.filters.minPrice = 500;
      this.filters.maxPrice = undefined;
    }

    if (ratingVal === 'all') {
      this.filters.minRating = undefined;
    } else {
      this.filters.minRating = Number(ratingVal);
    }

    this.filters.sort = sortVal || 'newest';
    this.filters.page = 1;
    this.loadProducts();
  }

  resetFilters() {
    this.filters = {
      category: 'all',
      keyword: '',
      minPrice: undefined,
      maxPrice: undefined,
      minRating: undefined,
      sort: 'newest',
      page: 1,
      limit: 8
    };

    const headerInput = document.getElementById('header-search-input');
    const catalogInput = document.getElementById('catalog-search-input');
    const priceSelect = document.getElementById('price-filter-select');
    const ratingSelect = document.getElementById('rating-filter-select');
    const sortSelect = document.getElementById('sort-select');

    if (headerInput) headerInput.value = '';
    if (catalogInput) catalogInput.value = '';
    if (priceSelect) priceSelect.value = 'all';
    if (ratingSelect) ratingSelect.value = 'all';
    if (sortSelect) sortSelect.value = 'newest';

    this.renderCategoryFilterTabs();
    this.loadProducts();
  }

  // --- PRODUCT QUICK VIEW & DETAILS MODAL ---
  async openProductModal(productId) {
    const modal = document.getElementById('product-modal');
    const content = document.getElementById('product-modal-content');
    if (!modal || !content) return;

    modal.classList.remove('hidden');
    content.innerHTML = `
      <div class="py-16 text-center text-rose-500">
        <div class="w-8 h-8 border-2 border-rose-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
        <p class="text-xs">Unveiling creation details...</p>
      </div>
    `;

    try {
      const data = await this.apiRequest(`/products/${productId}`);
      this.currentProduct = data.product;
      const reviews = data.reviews || [];

      const p = data.product;
      const hasDiscount = p.discountPrice && p.discountPrice > 0 && p.discountPrice < p.price;
      const currentPrice = hasDiscount ? p.discountPrice : p.price;
      const isWish = this.wishlist.includes(p._id);

      content.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          <!-- Gallery (Left) -->
          <div class="md:col-span-6 space-y-4">
            <div class="rounded-xl overflow-hidden aspect-4/3 bg-rose-50 border border-rose-100 shadow-sm">
              <img id="modal-main-image" src="${p.images[0]}" alt="${p.name}" class="w-full h-full object-cover" />
            </div>
            ${p.images.length > 1 ? `
              <div class="flex gap-2 overflow-x-auto pb-1">
                ${p.images.map((img, idx) => `
                  <button onclick="document.getElementById('modal-main-image').src='${img}'" class="w-16 h-16 rounded-lg overflow-hidden border border-rose-200 shrink-0 hover:border-rose-500">
                    <img src="${img}" alt="thumbnail ${idx}" class="w-full h-full object-cover" />
                  </button>
                `).join('')}
              </div>
            ` : ''}
          </div>

          <!-- Purchase Module (Right) -->
          <div class="md:col-span-6 space-y-5">
            <div>
              <div class="flex items-center justify-between">
                <span class="text-xs font-semibold uppercase tracking-wider text-rose-600">${p.category?.name || 'Luxury Collection'}</span>
                <span class="text-xs font-medium px-2 py-0.5 rounded ${p.stock > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}">
                  ${p.stock > 0 ? `In Stock (${p.stock} remaining)` : 'Sold Out'}
                </span>
              </div>
              <h2 class="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mt-1">${p.name}</h2>
              <div class="flex items-center gap-2 mt-2">
                <div class="flex text-amber-400">
                  ${'★'.repeat(Math.round(p.rating))}${'☆'.repeat(5 - Math.round(p.rating))}
                </div>
                <span class="text-xs font-semibold text-slate-700">${p.rating.toFixed(1)}</span>
                <span class="text-xs text-slate-400">·</span>
                <a href="#reviews-anchor" class="text-xs text-rose-600 underline font-medium">${reviews.length} verified reviews</a>
              </div>
            </div>

            <!-- Price -->
            <div class="py-3 px-4 bg-rose-50/60 rounded-xl border border-rose-100 flex items-baseline gap-3">
              <span class="font-serif text-3xl font-bold text-rose-600 tabular-nums">$${currentPrice.toFixed(2)}</span>
              ${hasDiscount ? `<span class="text-sm text-slate-400 line-through tabular-nums">$${p.price.toFixed(2)}</span>` : ''}
              ${hasDiscount ? `<span class="text-xs text-emerald-700 font-semibold bg-emerald-100 px-2 py-0.5 rounded">Save ${(100 - (p.discountPrice / p.price) * 100).toFixed(0)}%</span>` : ''}
            </div>

            <!-- Description -->
            <p class="text-xs sm:text-sm text-slate-600 leading-relaxed">${p.description}</p>

            <!-- Specifications Table -->
            ${p.specifications && p.specifications.length ? `
              <div class="border-t border-rose-100 pt-3 space-y-1.5 text-xs">
                <h4 class="font-semibold text-slate-800">Atelier Specifications:</h4>
                <div class="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  ${p.specifications.map((s) => `
                    <div><span class="text-slate-400 font-medium">${s.key}:</span> <span class="text-slate-700 font-medium">${s.value}</span></div>
                  `).join('')}
                </div>
              </div>
            ` : ''}

            <!-- Quantity & Actions -->
            <div class="pt-2 space-y-3">
              <div class="flex items-center gap-4">
                <div class="flex items-center border border-rose-200 rounded-lg bg-white overflow-hidden">
                  <button onclick="app.decrementModalQty()" class="px-3 py-2 text-slate-600 hover:bg-rose-50 cursor-pointer">-</button>
                  <input type="number" id="modal-product-qty" value="1" min="1" max="${p.stock}" class="w-12 text-center text-xs font-semibold focus:outline-hidden" />
                  <button onclick="app.incrementModalQty()" class="px-3 py-2 text-slate-600 hover:bg-rose-50 cursor-pointer">+</button>
                </div>
                <button onclick="app.addModalProductToCart()" ${p.stock <= 0 ? 'disabled' : ''} class="flex-1 py-3 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-sm hover:shadow-md transition-all cursor-pointer">
                  ${p.stock > 0 ? 'Add To Shopping Bag' : 'Out Of Stock'}
                </button>
                <button onclick="app.toggleWishlist('${p._id}')" class="p-3 border border-rose-200 rounded-lg hover:bg-rose-50 text-slate-600 hover:text-rose-600 cursor-pointer" title="Add to Wishlist">
                  <svg class="w-5 h-5 ${isWish ? 'fill-rose-600 text-rose-600' : ''}" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Verified Reviews Section -->
        <div id="reviews-anchor" class="mt-12 pt-8 border-t border-rose-200 space-y-6">
          <div class="flex items-center justify-between">
            <div>
              <h3 class="font-serif text-xl font-bold text-slate-900">Patron Reviews</h3>
              <p class="text-xs text-slate-500">Authenticated client feedback & ratings</p>
            </div>
          </div>

          <!-- Add Review Form -->
          <div class="bg-rose-50/40 p-4 rounded-xl border border-rose-200 space-y-3">
            <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wide">Write A Review</h4>
            <div class="flex items-center gap-2">
              <span class="text-xs text-slate-600 font-medium">Your Rating:</span>
              <select id="review-rating-input" class="px-2 py-1 bg-white border border-rose-300 rounded text-xs font-semibold text-amber-600">
                <option value="5">★★★★★ (5 Stars - Exceptional)</option>
                <option value="4">★★★★☆ (4 Stars - Very Good)</option>
                <option value="3">★★★☆☆ (3 Stars - Average)</option>
                <option value="2">★★☆☆☆ (2 Stars - Below Expectation)</option>
                <option value="1">★☆☆☆☆ (1 Star - Poor)</option>
              </select>
            </div>
            <textarea id="review-comment-input" rows="2" placeholder="Share your experience regarding fabric quality, fit, or texture..." class="w-full p-2.5 bg-white border border-rose-200 rounded-lg text-xs focus:outline-hidden focus:ring-1 focus:ring-rose-400"></textarea>
            <div class="flex justify-end">
              <button onclick="app.submitReview('${p._id}')" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-lg transition-colors cursor-pointer">
                Submit Review
              </button>
            </div>
          </div>

          <!-- Reviews List -->
          <div class="space-y-3 divide-y divide-rose-100">
            ${reviews.length ? reviews.map((r) => `
              <div class="pt-3 space-y-1 text-xs">
                <div class="flex items-center justify-between">
                  <div class="flex items-center gap-2">
                    <span class="font-bold text-slate-900">${r.userName}</span>
                    <span class="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">Verified Buyer</span>
                  </div>
                  <span class="text-[10px] text-slate-400">${new Date(r.createdAt).toLocaleDateString()}</span>
                </div>
                <div class="text-amber-400 text-xs">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
                <p class="text-slate-600 leading-relaxed">${r.comment}</p>
              </div>
            `).join('') : `
              <p class="text-xs text-slate-400 italic py-2">No customer reviews yet. Be the first to share your thoughts!</p>
            `}
          </div>
        </div>
      `;
    } catch (err) {
      content.innerHTML = `<p class="text-xs text-rose-700 text-center py-8">Failed to fetch product details.</p>`;
    }
  }

  closeProductModal() {
    const modal = document.getElementById('product-modal');
    if (modal) modal.classList.add('hidden');
    this.currentProduct = null;
  }

  incrementModalQty() {
    const input = document.getElementById('modal-product-qty');
    if (input) {
      const max = Number(input.getAttribute('max')) || 99;
      const current = Number(input.value) || 1;
      if (current < max) input.value = (current + 1).toString();
    }
  }

  decrementModalQty() {
    const input = document.getElementById('modal-product-qty');
    if (input) {
      const current = Number(input.value) || 1;
      if (current > 1) input.value = (current - 1).toString();
    }
  }

  addModalProductToCart() {
    if (!this.currentProduct) return;
    const qtyInput = document.getElementById('modal-product-qty');
    const qty = Number(qtyInput?.value) || 1;
    this.addToCart(this.currentProduct._id, qty);
    this.closeProductModal();
    this.toggleCartDrawer(true);
  }

  async submitReview(productId) {
    if (!this.currentUser) {
      this.showToast('Please sign in to post a review', 'info');
      this.openAuthModal();
      return;
    }

    const ratingInput = document.getElementById('review-rating-input');
    const commentInput = document.getElementById('review-comment-input');
    const rating = Number(ratingInput?.value) || 5;
    const comment = commentInput?.value.trim();

    if (!comment) {
      this.showToast('Please enter your review comments', 'error');
      return;
    }

    try {
      await this.apiRequest(`/reviews/product/${productId}`, 'POST', { rating, comment });
      this.showToast('Thank you! Your review has been recorded.', 'success');
      this.openProductModal(productId);
      this.loadProducts();
    } catch (err) {
      this.showToast(err.message || 'Failed submitting review', 'error');
    }
  }

  // --- SHOPPING CART & PROMO COUPONS ---
  toggleCartDrawer(open = true) {
    const drawer = document.getElementById('cart-drawer');
    const backdrop = document.getElementById('cart-drawer-backdrop');

    if (open) {
      this.renderCartDrawer();
      backdrop?.classList.remove('hidden');
      drawer?.classList.remove('translate-x-full');
    } else {
      drawer?.classList.add('translate-x-full');
      backdrop?.classList.add('hidden');
    }
  }

  addToCart(productId, quantity = 1) {
    const product = this.products.find((p) => p._id === productId) || this.currentProduct;
    if (!product) return;

    const existingIndex = this.cart.findIndex((item) => item.productId === productId);
    const activePrice = product.discountPrice && product.discountPrice > 0 ? product.discountPrice : product.price;

    if (existingIndex > -1) {
      const newQty = this.cart[existingIndex].quantity + quantity;
      if (newQty > product.stock) {
        this.showToast(`Only ${product.stock} units available in stock`, 'error');
        return;
      }
      this.cart[existingIndex].quantity = newQty;
    } else {
      if (quantity > product.stock) {
        this.showToast(`Only ${product.stock} units available in stock`, 'error');
        return;
      }
      this.cart.push({
        productId: product._id,
        name: product.name,
        price: activePrice,
        image: product.images[0] || '/src/assets/images/product_silk_dress_1793026300287.jpg',
        quantity,
        stock: product.stock
      });
    }

    this.saveCart();
    this.updateCartBadge();
    this.showToast(`Added "${product.name}" to bag`, 'success');
  }

  updateCartQty(productId, delta) {
    const index = this.cart.findIndex((item) => item.productId === productId);
    if (index === -1) return;

    const newQty = this.cart[index].quantity + delta;
    if (newQty <= 0) {
      this.cart.splice(index, 1);
    } else if (newQty > this.cart[index].stock) {
      this.showToast(`Max stock reached (${this.cart[index].stock})`, 'error');
      return;
    } else {
      this.cart[index].quantity = newQty;
    }

    this.saveCart();
    this.renderCartDrawer();
    this.updateCartBadge();
  }

  removeFromCart(productId) {
    this.cart = this.cart.filter((item) => item.productId !== productId);
    this.saveCart();
    this.renderCartDrawer();
    this.updateCartBadge();
    this.showToast('Item removed from shopping bag', 'info');
  }

  saveCart() {
    localStorage.setItem('samora_cart', JSON.stringify(this.cart));
  }

  updateCartBadge() {
    const badge = document.getElementById('cart-badge');
    const totalCount = this.cart.reduce((sum, item) => sum + item.quantity, 0);

    if (badge) {
      if (totalCount > 0) {
        badge.textContent = totalCount.toString();
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    }
  }

  renderCartDrawer() {
    const itemsContainer = document.getElementById('cart-drawer-items');
    const subtotalEl = document.getElementById('cart-subtotal');
    const discountRow = document.getElementById('cart-discount-row');
    const discountEl = document.getElementById('cart-discount');
    const shippingEl = document.getElementById('cart-shipping');
    const totalEl = document.getElementById('cart-total');
    const countEl = document.getElementById('drawer-cart-count');
    const checkoutBtn = document.getElementById('checkout-btn');
    const couponTag = document.getElementById('applied-coupon-tag');
    const couponText = document.getElementById('applied-coupon-text');

    if (!itemsContainer) return;

    const totalCount = this.cart.reduce((sum, item) => sum + item.quantity, 0);
    if (countEl) countEl.textContent = `(${totalCount} ${totalCount === 1 ? 'item' : 'items'})`;

    if (!this.cart.length) {
      itemsContainer.innerHTML = `
        <div class="py-16 text-center text-slate-400 space-y-3">
          <svg class="w-12 h-12 text-rose-200 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
          <p class="font-serif text-base font-semibold text-slate-700">Your bag is empty</p>
          <p class="text-xs text-slate-400">Discover our bespoke mulberry silk and skincare catalog.</p>
          <button onclick="app.toggleCartDrawer(false); app.scrollToSection('shop')" class="mt-2 px-4 py-2 bg-rose-600 text-white rounded-lg text-xs font-semibold">
            Explore Collection
          </button>
        </div>
      `;
      if (subtotalEl) subtotalEl.textContent = '$0.00';
      if (totalEl) totalEl.textContent = '$0.00';
      if (discountRow) discountRow.classList.add('hidden');
      if (checkoutBtn) checkoutBtn.setAttribute('disabled', 'true');
      return;
    }

    if (checkoutBtn) checkoutBtn.removeAttribute('disabled');

    itemsContainer.innerHTML = this.cart
      .map(
        (item) => `
        <div class="py-3 flex items-center gap-3">
          <img src="${item.image}" alt="${item.name}" class="w-16 h-16 rounded-lg object-cover bg-rose-50 border border-rose-100 shrink-0" />
          <div class="flex-1 min-w-0">
            <h4 class="text-xs font-semibold text-slate-900 truncate">${item.name}</h4>
            <div class="text-xs text-slate-500 tabular-nums mt-0.5">$${item.price.toFixed(2)} each</div>
            <div class="flex items-center gap-2 mt-1.5">
              <div class="flex items-center border border-rose-200 rounded bg-white">
                <button onclick="app.updateCartQty('${item.productId}', -1)" class="px-2 py-0.5 text-xs text-slate-600 hover:bg-rose-50 cursor-pointer">-</button>
                <span class="px-2 text-xs font-semibold tabular-nums">${item.quantity}</span>
                <button onclick="app.updateCartQty('${item.productId}', 1)" class="px-2 py-0.5 text-xs text-slate-600 hover:bg-rose-50 cursor-pointer">+</button>
              </div>
              <button onclick="app.removeFromCart('${item.productId}')" class="text-[11px] text-slate-400 hover:text-rose-600 ml-2 cursor-pointer">Remove</button>
            </div>
          </div>
          <div class="text-xs font-bold text-slate-900 tabular-nums">
            $${(item.price * item.quantity).toFixed(2)}
          </div>
        </div>
      `
      )
      .join('');

    // Calculations
    const subtotal = this.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const shipping = subtotal >= 150 ? 0 : 15;
    let discount = 0;

    if (this.appliedCoupon) {
      discount = this.appliedCoupon.discountAmount;
      if (couponTag) couponTag.classList.remove('hidden');
      if (couponText) couponText.textContent = `Promo "${this.appliedCoupon.code}" applied (-$${discount.toFixed(2)})`;
      if (discountRow) discountRow.classList.remove('hidden');
      if (discountEl) discountEl.textContent = `-$${discount.toFixed(2)}`;
    } else {
      if (couponTag) couponTag.classList.add('hidden');
      if (discountRow) discountRow.classList.add('hidden');
    }

    const total = Math.max(0, subtotal + shipping - discount);

    if (subtotalEl) subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
    if (shippingEl) shippingEl.textContent = shipping === 0 ? 'Complimentary' : `$${shipping.toFixed(2)}`;
    if (totalEl) totalEl.textContent = `$${total.toFixed(2)}`;
  }

  async applyCoupon() {
    const input = document.getElementById('cart-coupon-input');
    const code = input?.value.trim();
    if (!code) {
      this.showToast('Please type a promotional code', 'error');
      return;
    }

    const subtotal = this.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

    try {
      const data = await this.apiRequest('/coupons/validate', 'POST', { code, cartTotal: subtotal });
      this.appliedCoupon = {
        code: data.code,
        discountAmount: data.discountAmount,
        discountType: data.discountType,
        discountValue: data.discountValue
      };
      localStorage.setItem('samora_coupon', JSON.stringify(this.appliedCoupon));
      this.renderCartDrawer();
      this.showToast(data.message, 'success');
      if (input) input.value = '';
    } catch (err) {
      this.showToast(err.message || 'Invalid promotional code', 'error');
    }
  }

  removeCoupon() {
    this.appliedCoupon = null;
    localStorage.removeItem('samora_coupon');
    this.renderCartDrawer();
    this.showToast('Promotional discount removed', 'info');
  }

  copyCoupon(code) {
    navigator.clipboard?.writeText(code);
    const input = document.getElementById('cart-coupon-input');
    if (input) input.value = code;
    this.showToast(`Code "${code}" copied to clipboard!`, 'success');
  }

  // --- CHECKOUT & ORDER PLACEMENT ---
  openCheckoutModal() {
    if (!this.cart.length) {
      this.showToast('Your shopping bag is empty', 'error');
      return;
    }

    this.toggleCartDrawer(false);
    const modal = document.getElementById('checkout-modal');
    if (modal) modal.classList.remove('hidden');

    // Pre-populate if user logged in
    if (this.currentUser) {
      const nameInput = document.getElementById('checkout-name');
      const emailInput = document.getElementById('checkout-email');
      const phoneInput = document.getElementById('checkout-phone');
      const addrInput = document.getElementById('checkout-address');
      const cityInput = document.getElementById('checkout-city');
      const postalInput = document.getElementById('checkout-postal');

      if (nameInput) nameInput.value = this.currentUser.name || '';
      if (emailInput) emailInput.value = this.currentUser.email || '';
      if (phoneInput) phoneInput.value = this.currentUser.phone || '';

      const defAddress = (this.currentUser.addresses || []).find((a) => a.isDefault) || this.currentUser.addresses?.[0];
      if (defAddress) {
        if (addrInput) addrInput.value = defAddress.addressLine || '';
        if (cityInput) cityInput.value = defAddress.city || '';
        if (postalInput) postalInput.value = defAddress.postalCode || '';
      }
    }

    // Update checkout summary
    const subtotal = this.cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const shipping = subtotal >= 150 ? 0 : 15;
    const discount = this.appliedCoupon ? this.appliedCoupon.discountAmount : 0;
    const total = Math.max(0, subtotal + shipping - discount);

    const itemsSummary = document.getElementById('checkout-summary-items');
    const discountRow = document.getElementById('checkout-summary-discount-row');
    const discountSummary = document.getElementById('checkout-summary-discount');
    const shippingSummary = document.getElementById('checkout-summary-shipping');
    const totalSummary = document.getElementById('checkout-summary-total');

    if (itemsSummary) itemsSummary.textContent = `$${subtotal.toFixed(2)}`;
    if (shippingSummary) shippingSummary.textContent = shipping === 0 ? 'Complimentary' : `$${shipping.toFixed(2)}`;
    if (totalSummary) totalSummary.textContent = `$${total.toFixed(2)}`;

    if (discount > 0) {
      if (discountRow) discountRow.classList.remove('hidden');
      if (discountSummary) discountSummary.textContent = `-$${discount.toFixed(2)}`;
    } else {
      if (discountRow) discountRow.classList.add('hidden');
    }
  }

  closeCheckoutModal() {
    const modal = document.getElementById('checkout-modal');
    if (modal) modal.classList.add('hidden');
  }

  async handlePlaceOrder(event) {
    event.preventDefault();

    const fullName = document.getElementById('checkout-name').value;
    const email = document.getElementById('checkout-email').value;
    const phone = document.getElementById('checkout-phone').value;
    const addressLine = document.getElementById('checkout-address').value;
    const city = document.getElementById('checkout-city').value;
    const postalCode = document.getElementById('checkout-postal').value;
    const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cod';

    const orderPayload = {
      orderItems: this.cart,
      shippingAddress: {
        fullName,
        phone,
        addressLine,
        city,
        postalCode,
        country: 'India'
      },
      customerDetails: {
        name: fullName,
        email,
        phone
      },
      paymentMethod,
      couponCode: this.appliedCoupon ? this.appliedCoupon.code : undefined
    };

    const submitBtn = document.getElementById('place-order-submit-btn');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Securing order in atelier registry...';
    }

    try {
      const data = await this.apiRequest('/orders', 'POST', orderPayload);
      const createdOrder = data.order;

      // Reset cart and coupon
      this.cart = [];
      this.appliedCoupon = null;
      this.saveCart();
      localStorage.removeItem('samora_coupon');
      this.updateCartBadge();
      this.closeCheckoutModal();

      this.showToast(`Order #${createdOrder.orderNumber} placed successfully!`, 'success');
      this.displayOrderTrackingResult(createdOrder);
      this.openTrackOrderModal(createdOrder.orderNumber);
      this.loadProducts(); // Update stocks
    } catch (err) {
      this.showToast(err.message || 'Order placement failed', 'error');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Confirm & Place Order Now';
      }
    }
  }

  // --- ORDER TRACKING ---
  openTrackOrderModal(orderNumber = '') {
    const modal = document.getElementById('track-modal');
    if (modal) modal.classList.remove('hidden');

    const input = document.getElementById('track-order-input');
    if (input && orderNumber) {
      input.value = orderNumber;
      this.executeOrderTracking();
    }
  }

  closeTrackModal() {
    const modal = document.getElementById('track-modal');
    if (modal) modal.classList.add('hidden');
  }

  async executeOrderTracking() {
    const input = document.getElementById('track-order-input');
    const orderNumber = input?.value.trim();
    if (!orderNumber) {
      this.showToast('Please specify an Order Number', 'error');
      return;
    }

    try {
      const data = await this.apiRequest(`/orders/track/${encodeURIComponent(orderNumber)}`);
      this.displayOrderTrackingResult(data.order);
    } catch (err) {
      this.showToast(err.message || 'Order not found', 'error');
    }
  }

  displayOrderTrackingResult(order) {
    const resultBox = document.getElementById('tracking-result-box');
    if (!resultBox) return;

    resultBox.classList.remove('hidden');

    const statuses = ['placed', 'processing', 'shipped', 'delivered'];
    const currentIdx = statuses.indexOf(order.orderStatus);

    resultBox.innerHTML = `
      <div class="p-4 bg-rose-50/60 rounded-xl border border-rose-200 space-y-3">
        <div class="flex items-center justify-between">
          <div>
            <span class="text-[10px] font-bold uppercase tracking-wider text-rose-600">Consignment Code</span>
            <div class="font-mono text-sm font-bold text-slate-900">${order.orderNumber}</div>
          </div>
          <span class="px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${
            order.orderStatus === 'delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
          }">
            ${order.orderStatus}
          </span>
        </div>
        <div class="text-xs text-slate-600 flex justify-between border-t border-rose-100 pt-2">
          <span>Destination: <strong>${order.shippingCity || order.shippingAddress?.city || 'India'}</strong></span>
          <span>Payable: <strong class="tabular-nums font-serif text-slate-900">$${order.totalPrice?.toFixed(2)}</strong></span>
        </div>
      </div>

      <!-- Stepper Visual Timeline -->
      <div class="space-y-4">
        <h4 class="text-xs font-bold uppercase tracking-wider text-slate-800">Dispatch Status Timeline</h4>
        <div class="grid grid-cols-4 gap-2 text-center text-[11px]">
          ${statuses.map((st, idx) => {
            const isCompleted = idx <= currentIdx;
            return `
              <div class="space-y-1">
                <div class="h-2 rounded-full ${isCompleted ? 'bg-rose-600' : 'bg-slate-200'}"></div>
                <span class="font-semibold capitalize ${isCompleted ? 'text-rose-700' : 'text-slate-400'}">${st}</span>
              </div>
            `;
          }).join('')}
        </div>
      </div>

      <!-- Detailed Event Log -->
      <div class="space-y-2 border-t border-rose-100 pt-4">
        <h4 class="text-xs font-semibold text-slate-700">Chronological Logs:</h4>
        <div class="space-y-2 text-xs">
          ${(order.statusTimeline || []).map((tl) => `
            <div class="flex items-start gap-2 text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span class="w-2 h-2 rounded-full bg-rose-500 mt-1.5 shrink-0"></span>
              <div class="flex-1">
                <div class="font-semibold capitalize text-slate-800">${tl.status} - <span class="text-[10px] text-slate-400 font-normal">${new Date(tl.timestamp).toLocaleString()}</span></div>
                <p class="text-[11px] text-slate-500 mt-0.5">${tl.note}</p>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // --- WISHLIST ---
  async loadWishlist() {
    if (!this.currentUser) return;
    try {
      const data = await this.apiRequest('/wishlist');
      this.wishlist = (data.wishlist || []).map((p) => (typeof p === 'object' ? p._id : p));
      this.updateWishlistBadge();
    } catch {
      // Ignored
    }
  }

  updateWishlistBadge() {
    const badge = document.getElementById('wishlist-badge');
    if (!badge) return;

    if (this.wishlist.length > 0) {
      badge.textContent = this.wishlist.length.toString();
      badge.classList.remove('hidden');
    } else {
      badge.classList.add('hidden');
    }
  }

  async toggleWishlist(productId) {
    if (!this.currentUser) {
      this.showToast('Please sign in to save items to your wishlist', 'info');
      this.openAuthModal();
      return;
    }

    try {
      const data = await this.apiRequest(`/wishlist/toggle/${productId}`, 'POST');
      this.wishlist = data.wishlist || [];
      this.updateWishlistBadge();
      this.renderProductGrid();
      this.showToast(data.message, 'success');
      if (!document.getElementById('wishlist-modal')?.classList.contains('hidden')) {
        this.openWishlistModal();
      }
    } catch (err) {
      this.showToast(err.message || 'Wishlist update failed', 'error');
    }
  }

  async openWishlistModal() {
    if (!this.currentUser) {
      this.showToast('Please sign in to view your wishlist', 'info');
      this.openAuthModal();
      return;
    }

    const modal = document.getElementById('wishlist-modal');
    const container = document.getElementById('wishlist-items-container');
    if (!modal || !container) return;

    modal.classList.remove('hidden');
    container.innerHTML = `<p class="py-8 text-center text-xs text-rose-500">Loading saved favorites...</p>`;

    try {
      const data = await this.apiRequest('/wishlist');
      const items = data.wishlist || [];

      if (!items.length) {
        container.innerHTML = `
          <div class="py-12 text-center text-slate-400 space-y-2">
            <svg class="w-10 h-10 text-rose-200 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
            <p class="font-serif text-base font-bold text-slate-700">Your wishlist is pristine</p>
            <p class="text-xs text-slate-400">Save items you adore by tapping the heart icon on any card.</p>
          </div>
        `;
        return;
      }

      container.innerHTML = items
        .map((p) => `
          <div class="py-4 flex items-center justify-between gap-4">
            <div class="flex items-center gap-3">
              <img src="${p.images?.[0] || '/src/assets/images/product_silk_dress_1793026300287.jpg'}" alt="${p.name}" class="w-16 h-16 object-cover rounded-lg bg-rose-50 border border-rose-100" />
              <div>
                <span class="text-[10px] uppercase font-semibold text-rose-600">${p.category?.name || 'Creation'}</span>
                <h4 class="text-xs font-bold text-slate-900">${p.name}</h4>
                <div class="text-xs font-serif font-bold text-rose-600 mt-0.5">$${(p.discountPrice || p.price).toFixed(2)}</div>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <button onclick="app.addToCart('${p._id}'); app.toggleCartDrawer(true)" class="px-3.5 py-1.5 bg-rose-600 text-white rounded-lg text-xs font-semibold hover:bg-rose-700 cursor-pointer">
                Move to Bag
              </button>
              <button onclick="app.toggleWishlist('${p._id}')" class="p-1.5 text-slate-400 hover:text-rose-600 cursor-pointer" title="Remove">
                &times;
              </button>
            </div>
          </div>
        `)
        .join('');
    } catch {
      container.innerHTML = `<p class="py-8 text-center text-xs text-rose-700">Failed to load wishlist.</p>`;
    }
  }

  closeWishlistModal() {
    const modal = document.getElementById('wishlist-modal');
    if (modal) modal.classList.add('hidden');
  }

  // --- USER PROFILE & ORDER HISTORY ---
  async openAccountModal() {
    if (!this.currentUser) return;
    const modal = document.getElementById('account-modal');
    if (modal) modal.classList.remove('hidden');

    const nameEl = document.getElementById('account-user-name');
    const emailEl = document.getElementById('account-user-email');
    const avatarEl = document.getElementById('account-avatar-initials');

    if (nameEl) nameEl.textContent = this.currentUser.name;
    if (emailEl) emailEl.textContent = this.currentUser.email;
    if (avatarEl) avatarEl.textContent = this.currentUser.name[0].toUpperCase();

    this.switchAccountTab('orders');
  }

  closeAccountModal() {
    const modal = document.getElementById('account-modal');
    if (modal) modal.classList.add('hidden');
  }

  switchAccountTab(tab) {
    this.activeAccountTab = tab;
    const ordersTab = document.getElementById('account-orders-tab');
    const addressesTab = document.getElementById('account-addresses-tab');
    const btnOrders = document.getElementById('tab-btn-orders');
    const btnAddresses = document.getElementById('tab-btn-addresses');

    if (tab === 'orders') {
      ordersTab?.classList.remove('hidden');
      addressesTab?.classList.add('hidden');
      btnOrders?.classList.add('text-rose-600', 'border-b-2', 'border-rose-600');
      btnOrders?.classList.remove('text-slate-500');
      btnAddresses?.classList.remove('text-rose-600', 'border-b-2', 'border-rose-600');
      btnAddresses?.classList.add('text-slate-500');
      this.loadUserOrders();
    } else {
      ordersTab?.classList.add('hidden');
      addressesTab?.classList.remove('hidden');
      btnAddresses?.classList.add('text-rose-600', 'border-b-2', 'border-rose-600');
      btnAddresses?.classList.remove('text-slate-500');
      btnOrders?.classList.remove('text-rose-600', 'border-b-2', 'border-rose-600');
      btnOrders?.classList.add('text-slate-500');
      this.renderUserAddresses();
    }
  }

  async loadUserOrders() {
    const container = document.getElementById('account-orders-tab');
    if (!container) return;
    container.innerHTML = `<p class="py-8 text-center text-xs text-rose-500">Retrieving order logs...</p>`;

    try {
      const data = await this.apiRequest('/orders/my-orders');
      const orders = data.orders || [];

      if (!orders.length) {
        container.innerHTML = `
          <div class="py-12 text-center text-slate-400 space-y-2">
            <p class="font-serif text-base font-bold text-slate-700">No orders placed yet</p>
            <p class="text-xs text-slate-400">Your bespoke purchases will display here with live courier dispatch timelines.</p>
          </div>
        `;
        return;
      }

      container.innerHTML = orders
        .map((o) => `
          <div class="bg-rose-50/40 p-4 rounded-xl border border-rose-200/80 space-y-3">
            <div class="flex items-center justify-between text-xs">
              <div>
                <span class="text-slate-400 font-medium">Order:</span>
                <span class="font-mono font-bold text-slate-900">${o.orderNumber}</span>
                <span class="text-slate-400 ml-2">· ${new Date(o.createdAt).toLocaleDateString()}</span>
              </div>
              <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                o.orderStatus === 'delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }">${o.orderStatus}</span>
            </div>
            <div class="flex items-center justify-between text-xs border-t border-rose-100 pt-2">
              <span class="text-slate-600">${o.orderItems.length} items (${o.orderItems.map((i) => i.name).join(', ')})</span>
              <span class="font-serif font-bold text-slate-900 tabular-nums">$${o.totalPrice.toFixed(2)}</span>
            </div>
            <div class="flex justify-end pt-1">
              <button onclick="app.closeAccountModal(); app.openTrackOrderModal('${o.orderNumber}')" class="px-3 py-1 bg-white hover:bg-rose-50 text-rose-700 text-xs font-semibold rounded border border-rose-200 cursor-pointer">
                Track Live Progress
              </button>
            </div>
          </div>
        `)
        .join('');
    } catch {
      container.innerHTML = `<p class="py-8 text-center text-xs text-rose-700">Failed to load orders.</p>`;
    }
  }

  renderUserAddresses() {
    const container = document.getElementById('account-addresses-tab');
    if (!container) return;

    const addresses = this.currentUser?.addresses || [];
    container.innerHTML = `
      <div class="space-y-3">
        ${addresses.length ? addresses.map((addr) => `
          <div class="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
            <div>
              <div class="font-bold text-slate-900">${addr.fullName} <span class="font-normal text-slate-500">(${addr.phone})</span></div>
              <p class="text-slate-600 mt-0.5">${addr.addressLine}, ${addr.city} ${addr.postalCode}, ${addr.country}</p>
            </div>
            <button onclick="app.deleteAddress('${addr._id}')" class="text-rose-600 hover:text-rose-800 font-semibold cursor-pointer text-xs">
              Delete
            </button>
          </div>
        `).join('') : '<p class="text-xs text-slate-400 py-4">No shipping addresses saved.</p>'}
      </div>
    `;
  }

  async deleteAddress(addressId) {
    try {
      const data = await this.apiRequest(`/auth/address/${addressId}`, 'DELETE');
      if (this.currentUser) {
        this.currentUser.addresses = data.addresses;
      }
      this.renderUserAddresses();
      this.showToast('Address removed', 'info');
    } catch (err) {
      this.showToast(err.message || 'Failed deleting address', 'error');
    }
  }

  // --- ADMIN CONSOLE ---
  openAdminModal() {
    if (!this.currentUser || this.currentUser.role !== 'admin') {
      this.showToast('Administrator privileges required. Sign in as Admin.', 'error');
      this.openAuthModal();
      return;
    }

    const modal = document.getElementById('admin-modal');
    if (modal) modal.classList.remove('hidden');
    this.switchAdminTab(this.activeAdminTab || 'overview');
  }

  closeAdminModal() {
    const modal = document.getElementById('admin-modal');
    if (modal) modal.classList.add('hidden');
  }

  switchAdminTab(tab) {
    this.activeAdminTab = tab;
    const tabs = ['overview', 'products', 'orders', 'categories', 'coupons', 'users'];
    tabs.forEach((t) => {
      const btn = document.getElementById(`adm-tab-${t}`);
      const view = document.getElementById(`adm-view-${t}`);
      if (t === tab) {
        btn?.classList.add('bg-white', 'text-rose-600', 'shadow-xs');
        btn?.classList.remove('text-slate-600');
        view?.classList.remove('hidden');
      } else {
        btn?.classList.remove('bg-white', 'text-rose-600', 'shadow-xs');
        btn?.classList.add('text-slate-600');
        view?.classList.add('hidden');
      }
    });

    if (tab === 'overview') this.loadAdminOverview();
    if (tab === 'products') this.loadAdminProducts();
    if (tab === 'orders') this.loadAdminOrders();
    if (tab === 'categories') this.loadAdminCategories();
    if (tab === 'coupons') this.loadAdminCoupons();
    if (tab === 'users') this.loadAdminUsers();
  }

  async loadAdminOverview() {
    const view = document.getElementById('adm-view-overview');
    if (!view) return;
    view.innerHTML = `<p class="py-8 text-center text-xs text-rose-500">Calculating business analytics...</p>`;

    try {
      const data = await this.apiRequest('/admin/stats');
      const stats = data.stats;

      view.innerHTML = `
        <!-- KPI Metric Cards -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div class="p-4 bg-rose-50/60 rounded-xl border border-rose-200">
            <div class="text-[10px] font-bold uppercase tracking-wider text-rose-600">Total Net Revenue</div>
            <div class="font-serif text-2xl font-bold text-slate-900 mt-1 tabular-nums">$${stats.totalRevenue.toFixed(2)}</div>
            <div class="text-[11px] text-slate-500 mt-0.5">Delivered boutique orders</div>
          </div>
          <div class="p-4 bg-rose-50/60 rounded-xl border border-rose-200">
            <div class="text-[10px] font-bold uppercase tracking-wider text-rose-600">Total Orders</div>
            <div class="font-serif text-2xl font-bold text-slate-900 mt-1 tabular-nums">${stats.totalOrders}</div>
            <div class="text-[11px] text-slate-500 mt-0.5">${stats.statusCounts.placed || 0} placed / ${stats.statusCounts.shipped || 0} shipped</div>
          </div>
          <div class="p-4 bg-rose-50/60 rounded-xl border border-rose-200">
            <div class="text-[10px] font-bold uppercase tracking-wider text-rose-600">Catalog Offerings</div>
            <div class="font-serif text-2xl font-bold text-slate-900 mt-1 tabular-nums">${stats.totalProducts}</div>
            <div class="text-[11px] text-slate-500 mt-0.5">Across ${stats.totalCategories} departments</div>
          </div>
          <div class="p-4 bg-rose-50/60 rounded-xl border border-rose-200">
            <div class="text-[10px] font-bold uppercase tracking-wider text-rose-600">Registered Patrons</div>
            <div class="font-serif text-2xl font-bold text-slate-900 mt-1 tabular-nums">${stats.totalUsers}</div>
            <div class="text-[11px] text-slate-500 mt-0.5">Verified customer profiles</div>
          </div>
        </div>

        <!-- Recent Orders Table -->
        <div class="space-y-3">
          <h4 class="text-xs font-bold uppercase tracking-wider text-slate-800">Recent Boutique Orders</h4>
          <div class="border border-rose-100 rounded-xl overflow-hidden bg-white shadow-xs">
            <table class="w-full text-left text-xs">
              <thead class="bg-rose-50/60 border-b border-rose-100 text-slate-700 font-semibold">
                <tr>
                  <th class="p-3">Order Code</th>
                  <th class="p-3">Client</th>
                  <th class="p-3">Total</th>
                  <th class="p-3">Status</th>
                  <th class="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-rose-50">
                ${stats.recentOrders.map((o) => `
                  <tr class="hover:bg-rose-50/20">
                    <td class="p-3 font-mono font-bold">${o.orderNumber}</td>
                    <td class="p-3">${o.customerDetails?.name || 'Customer'}</td>
                    <td class="p-3 font-serif font-bold tabular-nums">$${o.totalPrice.toFixed(2)}</td>
                    <td class="p-3">
                      <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide ${
                        o.orderStatus === 'delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }">${o.orderStatus}</span>
                    </td>
                    <td class="p-3 text-right">
                      <button onclick="app.switchAdminTab('orders')" class="text-rose-600 hover:text-rose-800 underline font-semibold">Manage</button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      `;
    } catch {
      view.innerHTML = `<p class="text-xs text-rose-700 text-center py-6">Failed loading admin overview.</p>`;
    }
  }

  async loadAdminProducts() {
    const view = document.getElementById('adm-view-products');
    if (!view) return;
    view.innerHTML = `<p class="py-8 text-center text-xs text-rose-500">Loading catalog items...</p>`;

    try {
      const data = await this.apiRequest('/products?limit=50');
      const products = data.products || [];

      view.innerHTML = `
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-slate-900">Manage Catalog Products (${products.length})</h3>
          <button onclick="app.showAddProductForm()" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer">
            + Add New Product
          </button>
        </div>

        <div id="admin-product-form-box" class="hidden"></div>

        <div class="border border-rose-100 rounded-xl overflow-hidden bg-white shadow-xs">
          <table class="w-full text-left text-xs">
            <thead class="bg-rose-50/60 border-b border-rose-100 text-slate-700 font-semibold">
              <tr>
                <th class="p-3">Product</th>
                <th class="p-3">Category</th>
                <th class="p-3">Price</th>
                <th class="p-3">Stock</th>
                <th class="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-rose-50">
              ${products.map((p) => `
                <tr class="hover:bg-rose-50/20">
                  <td class="p-3 flex items-center gap-2">
                    <img src="${p.images[0]}" alt="${p.name}" class="w-9 h-9 object-cover rounded bg-rose-50 shrink-0" />
                    <span class="font-semibold text-slate-900 line-clamp-1">${p.name}</span>
                  </td>
                  <td class="p-3 text-slate-600">${p.category?.name || 'Silk'}</td>
                  <td class="p-3 font-serif font-bold tabular-nums">$${(p.discountPrice || p.price).toFixed(2)}</td>
                  <td class="p-3 font-semibold ${p.stock <= 5 ? 'text-red-600' : 'text-slate-700'}">${p.stock}</td>
                  <td class="p-3 text-right space-x-2">
                    <button onclick="app.deleteProduct('${p._id}')" class="text-red-600 hover:text-red-800 font-semibold cursor-pointer">Delete</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch {
      view.innerHTML = `<p class="text-xs text-rose-700 text-center py-6">Failed loading products.</p>`;
    }
  }

  showAddProductForm() {
    const box = document.getElementById('admin-product-form-box');
    if (!box) return;

    box.classList.remove('hidden');
    box.innerHTML = `
      <form onsubmit="app.handleCreateProduct(event)" class="bg-rose-50/60 p-5 rounded-xl border border-rose-200 space-y-4 text-xs">
        <div class="flex items-center justify-between pb-2 border-b border-rose-200">
          <h4 class="font-bold text-slate-900">Add New Luxury Product</h4>
          <button type="button" onclick="document.getElementById('admin-product-form-box').classList.add('hidden')" class="text-slate-400 hover:text-slate-700 text-lg">&times;</button>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block font-medium text-slate-700 mb-1">Product Name *</label>
            <input type="text" id="adm-p-name" required placeholder="Rose Silk Evening Gown" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Category *</label>
            <select id="adm-p-cat" required class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg">
              ${this.categories.map((c) => `<option value="${c._id}">${c.name}</option>`).join('')}
            </select>
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Retail Price ($) *</label>
            <input type="number" id="adm-p-price" step="0.01" required placeholder="240.00" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Discount Price ($ optional)</label>
            <input type="number" id="adm-p-discount" step="0.01" placeholder="199.00" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Stock Quantity *</label>
            <input type="number" id="adm-p-stock" required value="15" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Image URL</label>
            <input type="text" id="adm-p-image" value="/src/assets/images/product_silk_dress_1793026300287.jpg" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
          <div class="sm:col-span-2">
            <label class="block font-medium text-slate-700 mb-1">Description *</label>
            <textarea id="adm-p-desc" required rows="3" placeholder="Artisanal craftsmanship details..." class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg"></textarea>
          </div>
        </div>
        <div class="flex justify-end gap-2 pt-2">
          <button type="button" onclick="document.getElementById('admin-product-form-box').classList.add('hidden')" class="px-4 py-2 bg-white text-slate-700 border border-slate-200 rounded-lg">Cancel</button>
          <button type="submit" class="px-5 py-2 bg-rose-600 text-white font-semibold rounded-lg">Save Product</button>
        </div>
      </form>
    `;
  }

  async handleCreateProduct(event) {
    event.preventDefault();
    const name = document.getElementById('adm-p-name').value;
    const category = document.getElementById('adm-p-cat').value;
    const price = Number(document.getElementById('adm-p-price').value);
    const discountPrice = Number(document.getElementById('adm-p-discount').value) || 0;
    const stock = Number(document.getElementById('adm-p-stock').value);
    const image = document.getElementById('adm-p-image').value || '/src/assets/images/product_silk_dress_1793026300287.jpg';
    const description = document.getElementById('adm-p-desc').value;

    try {
      await this.apiRequest('/products', 'POST', {
        name,
        category,
        price,
        discountPrice,
        stock,
        images: [image],
        description,
        isFeatured: true
      });
      this.showToast('Product added successfully', 'success');
      this.loadAdminProducts();
      this.loadProducts();
    } catch (err) {
      this.showToast(err.message || 'Failed creating product', 'error');
    }
  }

  async deleteProduct(productId) {
    if (!confirm('Are you certain you wish to delete this creation from the catalog?')) return;
    try {
      await this.apiRequest(`/products/${productId}`, 'DELETE');
      this.showToast('Product deleted from boutique', 'info');
      this.loadAdminProducts();
      this.loadProducts();
    } catch (err) {
      this.showToast(err.message || 'Failed deleting product', 'error');
    }
  }

  async loadAdminOrders() {
    const view = document.getElementById('adm-view-orders');
    if (!view) return;
    view.innerHTML = `<p class="py-8 text-center text-xs text-rose-500">Loading orders registry...</p>`;

    try {
      const data = await this.apiRequest('/orders/admin/all?limit=50');
      const orders = data.orders || [];

      view.innerHTML = `
        <h3 class="text-sm font-bold text-slate-900">Manage Customer Consignments (${orders.length})</h3>
        <div class="border border-rose-100 rounded-xl overflow-hidden bg-white shadow-xs">
          <table class="w-full text-left text-xs">
            <thead class="bg-rose-50/60 border-b border-rose-100 text-slate-700 font-semibold">
              <tr>
                <th class="p-3">Order Number</th>
                <th class="p-3">Client</th>
                <th class="p-3">Address</th>
                <th class="p-3">Total</th>
                <th class="p-3">Current Status</th>
                <th class="p-3 text-right">Update Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-rose-50">
              ${orders.map((o) => `
                <tr class="hover:bg-rose-50/20">
                  <td class="p-3 font-mono font-bold">${o.orderNumber}</td>
                  <td class="p-3">
                    <div class="font-semibold text-slate-900">${o.customerDetails?.name}</div>
                    <div class="text-[10px] text-slate-400">${o.customerDetails?.phone}</div>
                  </td>
                  <td class="p-3 text-slate-600 line-clamp-1">${o.shippingAddress?.city}, ${o.shippingAddress?.country}</td>
                  <td class="p-3 font-serif font-bold tabular-nums">$${o.totalPrice.toFixed(2)}</td>
                  <td class="p-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide ${
                      o.orderStatus === 'delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }">${o.orderStatus}</span>
                  </td>
                  <td class="p-3 text-right">
                    <select onchange="app.updateOrderStatus('${o._id}', this.value)" class="px-2 py-1 bg-white border border-rose-200 rounded text-xs font-semibold text-slate-700 cursor-pointer">
                      <option value="placed" ${o.orderStatus === 'placed' ? 'selected' : ''}>Placed</option>
                      <option value="processing" ${o.orderStatus === 'processing' ? 'selected' : ''}>Processing</option>
                      <option value="shipped" ${o.orderStatus === 'shipped' ? 'selected' : ''}>Shipped</option>
                      <option value="delivered" ${o.orderStatus === 'delivered' ? 'selected' : ''}>Delivered</option>
                      <option value="cancelled" ${o.orderStatus === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                    </select>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch {
      view.innerHTML = `<p class="text-xs text-rose-700 text-center py-6">Failed loading orders.</p>`;
    }
  }

  async updateOrderStatus(orderId, newStatus) {
    try {
      await this.apiRequest(`/orders/admin/${orderId}/status`, 'PUT', {
        status: newStatus,
        note: `Status updated to ${newStatus} by Administrator.`
      });
      this.showToast(`Order status updated to ${newStatus.toUpperCase()}`, 'success');
      this.loadAdminOrders();
    } catch (err) {
      this.showToast(err.message || 'Failed updating status', 'error');
    }
  }

  async loadAdminCategories() {
    const view = document.getElementById('adm-view-categories');
    if (!view) return;

    view.innerHTML = `
      <div class="flex items-center justify-between">
        <h3 class="text-sm font-bold text-slate-900">Manage Departments (${this.categories.length})</h3>
        <button onclick="app.showAddCategoryForm()" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer">
          + Add Category
        </button>
      </div>

      <div id="admin-cat-form-box" class="hidden"></div>

      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        ${this.categories.map((c) => `
          <div class="p-4 bg-white border border-rose-100 rounded-xl flex items-center justify-between shadow-xs">
            <div class="flex items-center gap-3">
              <img src="${c.image || '/src/assets/images/product_beauty_serum_1793026300989.jpg'}" alt="${c.name}" class="w-10 h-10 object-cover rounded-full bg-rose-50 border border-rose-200" />
              <div>
                <h4 class="text-xs font-bold text-slate-900">${c.name}</h4>
                <p class="text-[10px] text-slate-400">${c.slug}</p>
              </div>
            </div>
            <button onclick="app.deleteCategory('${c._id}')" class="text-xs text-red-600 hover:text-red-800 font-semibold">Delete</button>
          </div>
        `).join('')}
      </div>
    `;
  }

  showAddCategoryForm() {
    const box = document.getElementById('admin-cat-form-box');
    if (!box) return;

    box.classList.remove('hidden');
    box.innerHTML = `
      <form onsubmit="app.handleCreateCategory(event)" class="bg-rose-50/60 p-4 rounded-xl border border-rose-200 space-y-3 text-xs">
        <div class="flex items-center justify-between">
          <h4 class="font-bold text-slate-900">Add Category</h4>
          <button type="button" onclick="document.getElementById('admin-cat-form-box').classList.add('hidden')" class="text-slate-400 hover:text-slate-700 text-lg">&times;</button>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="block font-medium text-slate-700 mb-1">Category Name</label>
            <input type="text" id="adm-c-name" required placeholder="Fine Gems & Diamonds" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Image URL</label>
            <input type="text" id="adm-c-image" value="/src/assets/images/product_silk_dress_1793026300287.jpg" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
        </div>
        <div class="flex justify-end gap-2">
          <button type="submit" class="px-4 py-2 bg-rose-600 text-white font-semibold rounded-lg">Save</button>
        </div>
      </form>
    `;
  }

  async handleCreateCategory(event) {
    event.preventDefault();
    const name = document.getElementById('adm-c-name').value;
    const image = document.getElementById('adm-c-image').value;

    try {
      await this.apiRequest('/categories', 'POST', { name, image });
      this.showToast('Category created', 'success');
      await this.loadCategories();
      this.loadAdminCategories();
    } catch (err) {
      this.showToast(err.message || 'Failed creating category', 'error');
    }
  }

  async deleteCategory(id) {
    if (!confirm('Delete this category?')) return;
    try {
      await this.apiRequest(`/categories/${id}`, 'DELETE');
      this.showToast('Category deleted', 'info');
      await this.loadCategories();
      this.loadAdminCategories();
    } catch (err) {
      this.showToast(err.message || 'Failed deleting category', 'error');
    }
  }

  async loadAdminCoupons() {
    const view = document.getElementById('adm-view-coupons');
    if (!view) return;
    view.innerHTML = `<p class="py-8 text-center text-xs text-rose-500">Loading coupons...</p>`;

    try {
      const data = await this.apiRequest('/coupons');
      const coupons = data.coupons || [];

      view.innerHTML = `
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-slate-900">Active Promotional Coupons (${coupons.length})</h3>
          <button onclick="app.showAddCouponForm()" class="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer">
            + New Promo Code
          </button>
        </div>

        <div id="admin-coupon-form-box" class="hidden"></div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          ${coupons.map((cp) => `
            <div class="p-4 bg-white border border-rose-100 rounded-xl space-y-2 shadow-xs">
              <div class="flex items-center justify-between">
                <span class="font-mono font-bold text-sm text-rose-700">${cp.code}</span>
                <span class="text-[10px] bg-rose-50 text-rose-600 px-2 py-0.5 rounded font-bold">${cp.discountType === 'percentage' ? `${cp.discountAmount}% OFF` : `$${cp.discountAmount} OFF`}</span>
              </div>
              <p class="text-xs text-slate-500">${cp.description || 'Promotional coupon'}</p>
              <div class="text-[10px] text-slate-400 flex justify-between border-t border-rose-50 pt-2">
                <span>Min: $${cp.minPurchaseAmount}</span>
                <span>Used: ${cp.usedCount} times</span>
              </div>
              <div class="flex justify-end pt-1">
                <button onclick="app.deleteCoupon('${cp._id}')" class="text-xs text-red-600 hover:text-red-800 font-semibold cursor-pointer">Delete</button>
              </div>
            </div>
          `).join('')}
        </div>
      `;
    } catch {
      view.innerHTML = `<p class="text-xs text-rose-700 text-center py-6">Failed loading coupons.</p>`;
    }
  }

  showAddCouponForm() {
    const box = document.getElementById('admin-coupon-form-box');
    if (!box) return;

    box.classList.remove('hidden');
    box.innerHTML = `
      <form onsubmit="app.handleCreateCoupon(event)" class="bg-rose-50/60 p-4 rounded-xl border border-rose-200 space-y-3 text-xs">
        <h4 class="font-bold text-slate-900">Issue New Promo Coupon</h4>
        <div class="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div>
            <label class="block font-medium text-slate-700 mb-1">Coupon Code *</label>
            <input type="text" id="adm-cp-code" required placeholder="SUMMER25" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg uppercase" />
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Discount Type *</label>
            <select id="adm-cp-type" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg">
              <option value="percentage">Percentage (%)</option>
              <option value="fixed">Fixed Dollar ($)</option>
            </select>
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Discount Value *</label>
            <input type="number" id="adm-cp-amount" required placeholder="25" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
          <div>
            <label class="block font-medium text-slate-700 mb-1">Min Order ($)</label>
            <input type="number" id="adm-cp-min" value="50" class="w-full px-3 py-2 bg-white border border-rose-200 rounded-lg" />
          </div>
        </div>
        <div class="flex justify-end gap-2">
          <button type="submit" class="px-4 py-2 bg-rose-600 text-white font-semibold rounded-lg">Create Coupon</button>
        </div>
      </form>
    `;
  }

  async handleCreateCoupon(event) {
    event.preventDefault();
    const code = document.getElementById('adm-cp-code').value;
    const discountType = document.getElementById('adm-cp-type').value;
    const discountAmount = Number(document.getElementById('adm-cp-amount').value);
    const minPurchaseAmount = Number(document.getElementById('adm-cp-min').value) || 0;

    try {
      await this.apiRequest('/coupons', 'POST', {
        code,
        discountType,
        discountAmount,
        minPurchaseAmount,
        validUntil: new Date('2027-12-31')
      });
      this.showToast(`Coupon ${code.toUpperCase()} created!`, 'success');
      this.loadAdminCoupons();
    } catch (err) {
      this.showToast(err.message || 'Failed creating coupon', 'error');
    }
  }

  async deleteCoupon(id) {
    if (!confirm('Delete this coupon?')) return;
    try {
      await this.apiRequest(`/coupons/${id}`, 'DELETE');
      this.showToast('Coupon removed', 'info');
      this.loadAdminCoupons();
    } catch (err) {
      this.showToast(err.message || 'Failed deleting coupon', 'error');
    }
  }

  async loadAdminUsers() {
    const view = document.getElementById('adm-view-users');
    if (!view) return;
    view.innerHTML = `<p class="py-8 text-center text-xs text-rose-500">Loading user directory...</p>`;

    try {
      const data = await this.apiRequest('/admin/users');
      const users = data.users || [];

      view.innerHTML = `
        <h3 class="text-sm font-bold text-slate-900">Patron Directory (${users.length})</h3>
        <div class="border border-rose-100 rounded-xl overflow-hidden bg-white shadow-xs">
          <table class="w-full text-left text-xs">
            <thead class="bg-rose-50/60 border-b border-rose-100 text-slate-700 font-semibold">
              <tr>
                <th class="p-3">Patron Name</th>
                <th class="p-3">Email Address</th>
                <th class="p-3">Role</th>
                <th class="p-3">Joined Date</th>
                <th class="p-3 text-right">Privilege</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-rose-50">
              ${users.map((u) => `
                <tr class="hover:bg-rose-50/20">
                  <td class="p-3 font-semibold text-slate-900">${u.name}</td>
                  <td class="p-3 text-slate-600">${u.email}</td>
                  <td class="p-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                      u.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-slate-100 text-slate-700'
                    }">${u.role}</span>
                  </td>
                  <td class="p-3 text-slate-400 text-[11px]">${new Date(u.createdAt).toLocaleDateString()}</td>
                  <td class="p-3 text-right">
                    <button onclick="app.toggleUserRole('${u._id}', '${u.role === 'admin' ? 'customer' : 'admin'}')" class="text-rose-600 hover:text-rose-800 font-semibold underline cursor-pointer">
                      Make ${u.role === 'admin' ? 'Customer' : 'Admin'}
                    </button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch {
      view.innerHTML = `<p class="text-xs text-rose-700 text-center py-6">Failed loading users.</p>`;
    }
  }

  async toggleUserRole(userId, newRole) {
    try {
      await this.apiRequest(`/admin/users/${userId}/role`, 'PUT', { role: newRole });
      this.showToast(`User role updated to ${newRole}`, 'success');
      this.loadAdminUsers();
    } catch (err) {
      this.showToast(err.message || 'Failed updating role', 'error');
    }
  }

  // --- RE-SEED STORE DATA ---
  async reseedDatabasePrompt() {
    if (!confirm('Re-seed the SAMORA database with fresh sample products, categories, reviews, and test accounts?')) {
      return;
    }

    try {
      this.showToast('Re-seeding database in background...', 'info');
      await this.apiRequest('/seed', 'POST');
      this.showToast('Database reset and seeded successfully!', 'success');
      await this.loadCategories();
      await this.loadProducts();
    } catch (err) {
      this.showToast(err.message || 'Seed failed', 'error');
    }
  }
}

// Bootstrap application once DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  const application = new SamoraApp();
  application.init();
});
