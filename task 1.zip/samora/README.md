# SAMORA — Premium E-Commerce Platform

A complete, production-grade e-commerce application featuring a luxury pink-and-white aesthetic, modern responsive user interface, full Express.js backend, and MongoDB database with Mongoose ODM.

---

## Architecture & Technology Stack

- **Frontend**: Pure HTML5, Tailwind CSS, and Vanilla JavaScript (ES Modules). Zero framework bloat.
- **Backend**: Node.js & Express.js REST API with modular routing and controller logic.
- **Database**: MongoDB with Mongoose ODM (with automatic fallback to embedded `mongodb-memory-server` for instant zero-configuration testing).
- **Authentication**: Stateless JSON Web Tokens (JWT) stored in HTTP headers/localStorage with bcryptjs password hashing.
- **Visual Design**: Domain-authentic luxury styling inspired by high-end fashion and cosmetic houses, incorporating Cormorant Garamond / Playfair Display editorial typography, delicate rose gold tones, and fluid micro-animations.

---

## Core Features Implemented

1. **Storefront & Navigation**
   - Compliant Top Bar Contract: Brand wordmark, collection navigation links, live search toggle, wishlist counter, shopping bag drawer trigger, and user account modal.
   - Dismissible promotional announcement ribbon with coupon copy button.
   - Editorial Hero Campaign showcase with 16:9 lifestyle assets.
   - Department categories grid with dynamic filtering.
2. **Catalog & Discovery**
   - Live debounced keyword search across names, tags, and descriptions.
   - Multi-criteria filtering by category, price ranges ($0-100, $100-250, $250-500, $500+), and customer ratings.
   - Real-time sorting by Price (Low to High / High to Low), Customer Rating, and Newest Additions.
   - Pagination with active state indicators.
3. **Product Details & Customer Reviews**
   - Quick-view overlay and comprehensive purchase modal.
   - Multi-angle image thumbnails gallery and atelier specification tables.
   - Stock status tracking with inventory warning.
   - Authenticated customer reviews system with 5-star rating selector and automated product rating recalculation.
4. **Shopping Bag & Promotional Discounts**
   - Interactive slide-over cart drawer.
   - Quantity increment/decrement steppers with live inventory ceiling validation.
   - Item removal and real-time subtotal calculation.
   - Automated complimentary shipping threshold ($150+ free, else $15).
   - Promo coupon engine (`SAMORA15`, `PINK20`, `LUXURY50`) with instant validation and discount computation.
5. **Checkout & Order Placement**
   - Multi-step customer address verification form with automatic profile prefill.
   - Flexible payment method selection: Cash on Delivery (COD), Credit/Debit Card, or UPI/QR scan.
   - Atomic database order creation with automated product inventory deduction.
6. **Live Order Tracking & Status Timelines**
   - Interactive consignment tracker with chronological status events:
     `Placed` → `Processing` → `Shipped` → `Delivered`.
   - Real-time visual progress step bar.
7. **Customer Account Portal**
   - Order history with past consignment details and instant tracking launcher.
   - Saved shipping addresses manager with default selection and deletion.
   - Curated Wishlist with one-click "Move to Bag".
8. **Comprehensive Admin Dashboard Console**
   - **Overview & Analytics**: Net Revenue ($), total order volume, active products, registered patrons, and recent orders log.
   - **Product Management**: Full CRUD operations — Add new luxury product with images, price, stock, and specifications; delete catalog items.
   - **Order Dispatch Management**: Real-time status updater dropdown with live customer notification log generation.
   - **Category Management**: Create and delete store departments.
   - **Promotional Coupon Management**: Create percentage or fixed-amount discount codes with minimum order thresholds.
   - **User Directory**: View registered customer profiles and toggle administrator privileges.

---

## Default Testing Accounts

| Role | Email Address | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@samora.com` | `Admin@123` | Full access to Admin Console, Products, Orders, Coupons, and Users |
| **Customer** | `customer@samora.com` | `Customer@123` | Shopping, Wishlist, Order History, Checkout, and Reviews |

*Tip: In the Sign-In modal, convenient "Fill Customer Demo" and "Fill Admin Demo" buttons are available for instant 1-click testing.*

---

## Active Promotional Coupon Codes

- `SAMORA15` — 15% off any order (Min: $50)
- `PINK20` — 20% off orders over $100
- `LUXURY50` — Flat $50 off orders over $250

---

## Installation & Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Ensure your configuration has:
```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/samora_ecommerce
JWT_SECRET=samora_luxury_secret_jwt_key_2026
```
*(If no external MongoDB instance is running, the application will automatically spin up an embedded in-memory MongoDB server seamlessly).*

### 3. Seed Database
Seed initial categories, sample luxury products, reviews, active promo codes, and test accounts:
```bash
npm run seed
```
*(Alternatively, you can click "Re-Seed Sample Store Data" in the footer of the website or call `POST /api/seed`)*

### 4. Start Development Server
```bash
npm run dev
```

### 5. Access Website
Open your browser and navigate to:
```
http://localhost:3000
```
